#!/usr/bin/env python3
"""Add CSV safety guards to the restored Core/Src/main.c.

This patch assumes the combined catalog/UI changes remain installed and adds
backend protection so CSV exports cannot be opened by WAV-only operations.
"""

from pathlib import Path
import re
import shutil

MAIN_C = Path("Core/Src/main.c")
MARKER = "CSV_SAFETY_GUARDS_MAIN_PATCH"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


if not MAIN_C.exists():
    fail("Run this script from the ~/429_DSP project root")

raw = MAIN_C.read_bytes()
if b"\x00" in raw:
    fail("Binary NUL found in Core/Src/main.c")

text = raw.decode("utf-8")

if MARKER in text:
    fail("CSV safety guards are already installed")

if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact found in Core/Src/main.c")

for prerequisite in (
    "FFTEXPORT_CSV_PATCH",
    "FFT_EVENT_SCAN_MARKERS_PATCH",
    "RecordingCatalog_GetSelected()",
    "case UI_ACTION_VIEW_WAVEFORM:",
    "case UI_ACTION_VIEW_SPECTRUM:",
    "case UI_ACTION_FILE_INFO:",
    "case UI_ACTION_FILE_RENAME_OPEN:",
    "case UI_ACTION_FILE_DELETE:",
):
    if prerequisite not in text:
        fail("Missing prerequisite: " + prerequisite)

# The catalog header must already provide these functions after the combined
# catalog/UI patch. They need not yet appear in main.c.
catalog_header = Path("Core/Inc/recording_catalog.h")
if not catalog_header.exists():
    fail("Missing Core/Inc/recording_catalog.h")
header_text = catalog_header.read_text(encoding="utf-8")
for api in (
    "RecordingCatalog_SelectedIsWav",
    "RecordingCatalog_SelectedIsCsv",
):
    if api not in header_text:
        fail("Missing catalog API: " + api)

backup = MAIN_C.with_name(MAIN_C.name + ".before_csv_safety_guards")
if not backup.exists():
    shutil.copy2(MAIN_C, backup)

# Add a single feature marker near the recorded FFT markers.
text = once(
    text,
    "/* FFT_EVENT_SCAN_MARKERS_PATCH */\n",
    """/* FFT_EVENT_SCAN_MARKERS_PATCH */
/* CSV_SAFETY_GUARDS_MAIN_PATCH */
""",
    "FFT event scan marker",
)

# Protect the waveform loader.
text = once(
    text,
    """        case UI_ACTION_VIEW_WAVEFORM:
            if (Capture_IsRecorderActive())
""",
    """        case UI_ACTION_VIEW_WAVEFORM:
            if (!RecordingCatalog_SelectedIsWav())
            {
                UART_SendString(
                    "WAVE blocked: select a WAV file\\r\\n");
                break;
            }

            if (Capture_IsRecorderActive())
""",
    "waveform action entry",
)

# Protect the recorded FFT loader.
text = once(
    text,
    """        case UI_ACTION_VIEW_SPECTRUM:
            if (Capture_IsRecorderActive())
""",
    """        case UI_ACTION_VIEW_SPECTRUM:
            if (!RecordingCatalog_SelectedIsWav())
            {
                UART_SendString(
                    "FFT blocked: select a WAV file\\r\\n");
                break;
            }

            if (Capture_IsRecorderActive())
""",
    "recorded FFT action entry",
)

# CSV INFO stays on the type-aware file action screen. It never enters the WAV
# header parser. The selected filename and file size are already shown there.
text = once(
    text,
    """        case UI_ACTION_FILE_INFO:
        {
            UI_WavInfo info;

            result = UI_LoadSelectedWavInfo(&info);
""",
    """        case UI_ACTION_FILE_INFO:
        {
            UI_WavInfo info;

            if (RecordingCatalog_SelectedIsCsv())
            {
                UART_SendString("UI FFT CSV info: ");
                UART_SendString(RecordingCatalog_GetSelected());
                UART_SendString("\\r\\n");
                UI_ShowFileActions();
                break;
            }

            result = UI_LoadSelectedWavInfo(&info);
""",
    "file info action entry",
)

# Rename remains WAV-only.
text = once(
    text,
    """        case UI_ACTION_FILE_RENAME_OPEN:
            if (Capture_IsRecorderActive())
""",
    """        case UI_ACTION_FILE_RENAME_OPEN:
            if (!RecordingCatalog_SelectedIsWav())
            {
                UART_SendString(
                    "Rename blocked: select a WAV file\\r\\n");
                break;
            }

            if (Capture_IsRecorderActive())
""",
    "rename action entry",
)

# Make selection/delete messages generic because both WAV and CSV are valid
# catalog entries. Deletion is intentionally allowed for either type.
text = text.replace(
    "Select a valid WAV before OPEN",
    "Select a valid file before OPEN")
text = text.replace(
    "Select a valid WAV before delete",
    "Select a valid file before delete")
text = text.replace(
    "UI selected WAV: ",
    "UI selected file: ")
text = text.replace(
    "UI file browser has no WAV files",
    "UI file browser has no WAV or CSV files")

text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"

if text.count("{") != text.count("}"):
    fail("Brace balance failed before write")
if text.count("/*") != text.count("*/"):
    fail("Comment balance failed before write")
if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact generated")
if b"\x00" in text.encode("utf-8"):
    fail("Binary NUL generated")

for required in (
    MARKER,
    "WAVE blocked: select a WAV file",
    "FFT blocked: select a WAV file",
    "Rename blocked: select a WAV file",
    "RecordingCatalog_SelectedIsCsv()",
    "UI FFT CSV info:",
):
    if required not in text:
        fail("Missing generated item: " + required)

# Ensure each protected action still appears exactly once.
for action in (
    "case UI_ACTION_VIEW_WAVEFORM:",
    "case UI_ACTION_VIEW_SPECTRUM:",
    "case UI_ACTION_FILE_INFO:",
    "case UI_ACTION_FILE_RENAME_OPEN:",
):
    if text.count(action) != 1:
        fail("Action missing or duplicated: " + action)

MAIN_C.write_text(text, encoding="utf-8")

print("CSV safety guards applied successfully to Core/Src/main.c.")
print("CSV files are blocked from WAVE, FFT, and RENAME actions.")
print("CSV INFO stays on the safe file-information action screen.")
print("CSV deletion remains allowed through the existing confirmation path.")
print("Next: make clean && make -j4")
