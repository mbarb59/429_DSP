#!/usr/bin/env python3
"""Add collapsible recorded-FFT timeline and three in-graph readings.

Behavior:
- Timeline hidden by default.
- Tap the recorded FFT plot to show or hide it.
- Timeline auto-hides after three seconds of inactivity.
- Dragging previews the cursor; the requested segment loads once on release.
- Full-height dBFS plot is restored whenever the timeline is hidden.
"""

from pathlib import Path
import re
import shutil

UI_C = Path("Core/Src/ui.c")
MARKER = "FFT_COLLAPSIBLE_TIMELINE_READINGS_PATCH"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


def function_slice(text, signature, next_signature):
    start = text.find(signature)
    end = text.find(next_signature, start)
    if start < 0 or end < 0:
        fail("Could not isolate " + signature.strip())
    return start, end, text[start:end]


if not UI_C.exists():
    fail(f"Missing required file: {UI_C}")

raw = UI_C.read_bytes()
if b"\x00" in raw:
    fail("Binary NUL found in Core/Src/ui.c")

text = raw.decode("utf-8")

if MARKER in text:
    fail("Collapsible timeline/readings patch is already installed")

if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact found in Core/Src/ui.c")

for prerequisite in (
    "RECORDED_FFT_TIMELINE_SCRUBBER_PATCH",
    "FFT_TIMELINE_SEPARATOR_PATCH",
    "RECORDED_FFT_TIMELINE_GEOMETRY_FIX",
    "FFT_PEAK_UNITS_NO_STDIO_FIX",
    "ui_append_uint_text",
    "ui_format_peak_frequency",
    "UI_RECORDED_FFT_GRAPH_HEIGHT",
    "ui_draw_fft_timeline();",
):
    if prerequisite not in text:
        fail("Missing prerequisite: " + prerequisite)

backup = UI_C.with_name(UI_C.name + ".before_collapsible_fft_timeline")
if not backup.exists():
    shutil.copy2(UI_C, backup)

# -------------------------------------------------------------------------
# Constants and state
# -------------------------------------------------------------------------
text = once(
    text,
    "#define UI_FFT_TIMELINE_TOUCH_MARGIN       4U\n",
    """#define UI_FFT_TIMELINE_TOUCH_MARGIN       4U
#define UI_FFT_TIMELINE_AUTO_HIDE_MS      3000U
""",
    "timeline touch margin",
)

text = once(
    text,
    """    bool fft_timeline_dragging;
    uint32_t fft_timeline_preview_segment;
    uint32_t requested_fft_segment;
""",
    """    bool fft_timeline_dragging;
    bool fft_timeline_visible;
    uint32_t fft_timeline_preview_segment;
    uint32_t requested_fft_segment;
    uint32_t fft_timeline_last_interaction_ms;
""",
    "timeline UI state",
)

text = once(
    text,
    """    ui.fft_timeline_dragging = false;
    ui.fft_timeline_preview_segment = 0U;
    ui.requested_fft_segment = 0U;
""",
    """    ui.fft_timeline_dragging = false;
    ui.fft_timeline_visible = false;
    ui.fft_timeline_preview_segment = 0U;
    ui.requested_fft_segment = 0U;
    ui.fft_timeline_last_interaction_ms = 0U;
""",
    "timeline initialization",
)

text = once(
    text,
    "static void ui_draw_fft_timeline(void);\n",
    """static void ui_draw_fft_timeline(void);
static void ui_draw_fft_readings(void);
static int32_t ui_recorded_fft_graph_bottom(void);
static uint32_t ui_recorded_fft_graph_height(void);
static void ui_format_time_seconds(uint32_t time_ms,
                                   char *buffer,
                                   uint32_t buffer_size);
""",
    "timeline prototype",
)

# -------------------------------------------------------------------------
# Dynamic recorded-FFT geometry
# -------------------------------------------------------------------------
geometry_helpers = '''static int32_t ui_recorded_fft_graph_bottom(void)
{
    return ui.fft_timeline_visible ?
        UI_RECORDED_FFT_GRAPH_BOTTOM : UI_GRAPH_BOTTOM;
}

static uint32_t ui_recorded_fft_graph_height(void)
{
    return (uint32_t)(ui_recorded_fft_graph_bottom() -
                      UI_GRAPH_TOP + 1);
}

'''
text = once(
    text,
    "static int32_t ui_db_tenths_to_y(int16_t db_tenths)\n",
    geometry_helpers +
    "static int32_t ui_db_tenths_to_y(int16_t db_tenths)\n",
    "dB mapping implementation",
)

text = once(
    text,
    """    uint32_t usable_height =
        (uint32_t)UI_RECORDED_FFT_GRAPH_HEIGHT - 2U;
""",
    """    uint32_t usable_height =
        ui_recorded_fft_graph_height() - 2U;
""",
    "dynamic recorded FFT dB height",
)

# Restrict changes to the dB grid function.
start, end, db_grid = function_slice(
    text,
    "static void ui_draw_db_grid(void)\n",
    "static void ui_draw_db_spectrum_trace(void)\n",
)
db_grid = once(
    db_grid,
    "                     UI_RECORDED_FFT_GRAPH_HEIGHT,\n",
    "                     ui_recorded_fft_graph_height(),\n",
    "dynamic dB grid border height",
)
db_grid = once(
    db_grid,
    "                         UI_RECORDED_FFT_GRAPH_BOTTOM,\n",
    "                         ui_recorded_fft_graph_bottom(),\n",
    "dynamic dB vertical grid bottom",
)
text = text[:start] + db_grid + text[end:]

# Restrict the peak-clamp change to the dB peak function.
start, end, db_peak = function_slice(
    text,
    "static void ui_draw_db_peak_marker(void)\n",
    "static void ui_draw_grid(void)\n",
)
db_peak = once(
    db_peak,
    """    if (peak_y > UI_RECORDED_FFT_GRAPH_BOTTOM)
    {
        peak_y = UI_RECORDED_FFT_GRAPH_BOTTOM;
    }
""",
    """    if (peak_y > ui_recorded_fft_graph_bottom())
    {
        peak_y = ui_recorded_fft_graph_bottom();
    }
""",
    "dynamic dB peak clamp",
)
text = text[:start] + db_peak + text[end:]

# -------------------------------------------------------------------------
# Compact time formatter and in-graph readings
# -------------------------------------------------------------------------
format_time = '''static void ui_format_time_seconds(uint32_t time_ms,
                                   char *buffer,
                                   uint32_t buffer_size)
{
    uint32_t position = 0U;
    uint32_t rounded_hundredths;
    uint32_t whole_seconds;
    uint32_t fraction;

    if ((buffer == NULL) || (buffer_size == 0U))
    {
        return;
    }

    buffer[0] = '\\0';
    rounded_hundredths = (time_ms + 5U) / 10U;
    whole_seconds = rounded_hundredths / 100U;
    fraction = rounded_hundredths % 100U;

    position = ui_append_uint_text(buffer,
                                   buffer_size,
                                   position,
                                   whole_seconds,
                                   1U);
    position = ui_append_text(buffer,
                              buffer_size,
                              position,
                              ".");
    position = ui_append_uint_text(buffer,
                                   buffer_size,
                                   position,
                                   fraction,
                                   2U);
    (void)ui_append_text(buffer,
                        buffer_size,
                        position,
                        " s");
}

static void ui_draw_fft_readings(void)
{
    const WavFftViewerInfo *info = WavFftViewer_GetInfo();
    char frequency_text[16];
    char time_text[16];

    if ((info == NULL) || !info->active)
    {
        return;
    }

    Display_FillRect(34, 34, 106, 18, COLOR_BLACK);
    Display_DrawString(36, 36, "SEG", COLOR_WHITE, COLOR_BLACK);
    ui_draw_uint(62, 36, info->segment_index + 1U, COLOR_YELLOW);
    Display_DrawString(92, 36, "/", COLOR_GRAY, COLOR_BLACK);
    ui_draw_uint(102, 36, info->segment_count, COLOR_YELLOW);

    ui_format_time_seconds(info->segment_time_ms,
                           time_text,
                           sizeof(time_text));
    Display_FillRect(142, 34, 88, 18, COLOR_BLACK);
    Display_DrawString(144, 36, "T", COLOR_WHITE, COLOR_BLACK);
    Display_DrawString(158, 36, time_text, COLOR_CYAN, COLOR_BLACK);

    ui_format_peak_frequency(FFT_GetPeakFrequency(),
                             frequency_text,
                             sizeof(frequency_text));
    Display_FillRect(142, 54, 176, 18, COLOR_BLACK);
    Display_DrawString(144, 56, "PEAK", COLOR_WHITE, COLOR_BLACK);
    Display_DrawString(180, 56, frequency_text, COLOR_GREEN, COLOR_BLACK);
    ui_draw_signed_db(264, 56,
                      FFT_GetPeakDbTenths(),
                      COLOR_YELLOW);
    Display_DrawString(304, 56, "dB", COLOR_GRAY, COLOR_BLACK);
}

'''
text = once(
    text,
    "static bool ui_fft_timeline_contains(uint16_t x, uint16_t y)\n",
    format_time +
    "static bool ui_fft_timeline_contains(uint16_t x, uint16_t y)\n",
    "timeline hit-test implementation",
)

# Hit-test timeline only when it is visible.
text = once(
    text,
    """    return (x >= UI_FFT_TIMELINE_X) &&
""",
    """    return ui.fft_timeline_visible &&
           (x >= UI_FFT_TIMELINE_X) &&
""",
    "timeline visibility hit-test",
)

# Timeline drawing returns immediately when hidden.
text = once(
    text,
    """    if ((info == NULL) || !info->active ||
        (info->segment_count == 0U))
""",
    """    if (!ui.fft_timeline_visible ||
        (info == NULL) || !info->active ||
        (info->segment_count == 0U))
""",
    "hidden timeline draw guard",
)

# Draw readings after the trace, then timeline if visible.
text = once(
    text,
    """            ui_draw_db_spectrum_trace();
            ui_draw_db_peak_marker();
            ui_draw_fft_timeline();
""",
    """            ui_draw_db_spectrum_trace();
            ui_draw_db_peak_marker();
            ui_draw_fft_readings();
            ui_draw_fft_timeline();
""",
    "recorded FFT overlays",
)

# -------------------------------------------------------------------------
# Timeline show/hide interaction
# -------------------------------------------------------------------------
# Fresh entry stays hidden unless already visible during a segment reload.
text = once(
    text,
    """    ui.fft_timeline_dragging = false;
    ui.fft_timeline_preview_segment =
        WavFftViewer_GetInfo()->segment_index;
""",
    """    ui.fft_timeline_dragging = false;
    ui.fft_timeline_preview_segment =
        WavFftViewer_GetInfo()->segment_index;
""",
    "recorded FFT timeline reset",
)

# Touching the timeline refreshes the auto-hide timer. Restrict this edit to
# ui_handle_touch_down(), because the same assignment also appears in move.
start, end, touch_down = function_slice(
    text,
    "static void ui_handle_touch_down(\n",
    "static void ui_handle_touch_move(const STMPE811_TouchData *touch)\n",
)
touch_down = once(
    touch_down,
    """        ui.requested_fft_segment =
            ui.fft_timeline_preview_segment;
        ui.graph_dirty = true;
""",
    """        ui.requested_fft_segment =
            ui.fft_timeline_preview_segment;
        ui.fft_timeline_last_interaction_ms = HAL_GetTick();
        ui.graph_dirty = true;
""",
    "timeline touch-down interaction timestamp",
)
text = text[:start] + touch_down + text[end:]

# Move branch has a similar sequence, so isolate the function.
start, end, touch_move = function_slice(
    text,
    "static void ui_handle_touch_move(const STMPE811_TouchData *touch)\n",
    "static void ui_handle_touch_up(void)\n",
)
touch_move = once(
    touch_move,
    """        ui.requested_fft_segment =
            ui.fft_timeline_preview_segment;
        ui.graph_dirty = true;
""",
    """        ui.requested_fft_segment =
            ui.fft_timeline_preview_segment;
        ui.fft_timeline_last_interaction_ms = HAL_GetTick();
        ui.graph_dirty = true;
""",
    "timeline drag interaction timestamp",
)
text = text[:start] + touch_move + text[end:]

# On release, keep visible and restart three-second timer.
start, end, touch_up = function_slice(
    text,
    "static void ui_handle_touch_up(void)\n",
    "static void ui_pan_pixels(int32_t pixel_delta)\n",
)
touch_up = once(
    touch_up,
    """        ui.pending_action = UI_ACTION_FFT_LOAD_SEGMENT;
        ui.fft_timeline_dragging = false;
""",
    """        ui.pending_action = UI_ACTION_FFT_LOAD_SEGMENT;
        ui.fft_timeline_dragging = false;
        ui.fft_timeline_visible = true;
        ui.fft_timeline_last_interaction_ms = HAL_GetTick();
""",
    "timeline release visibility",
)

# Insert graph-tap toggle before the existing FILES branch.
files_branch = """    else if ((ui.mode == UI_MODE_RECORDER) &&
"""
toggle_branch = """    else if (!ui.dragging &&
             (ui.mode == UI_MODE_RECORDED_FFT) &&
             (ui.touch_start_y >= UI_GRAPH_TOP) &&
             (ui.touch_start_y <= UI_GRAPH_BOTTOM) &&
             (ui.previous_touch_y >= UI_GRAPH_TOP) &&
             (ui.previous_touch_y <= UI_GRAPH_BOTTOM))
    {
        ui.fft_timeline_visible = !ui.fft_timeline_visible;
        ui.fft_timeline_last_interaction_ms = HAL_GetTick();
        ui.graph_dirty = true;
        UART_SendString(ui.fft_timeline_visible ?
            "UI FFT TIMELINE SHOW\\r\\n" :
            "UI FFT TIMELINE HIDE\\r\\n");
        action_executed = true;
    }
    else if ((ui.mode == UI_MODE_RECORDER) &&
"""
touch_up = once(
    touch_up,
    files_branch,
    toggle_branch,
    "recorded FFT graph-tap toggle",
)

# Hide timeline when leaving recorded FFT through BACK.
touch_up = once(
    touch_up,
    """    ui.touch_active = false;
    ui.dragging = false;
""",
    """    ui.touch_active = false;
    ui.dragging = false;
""",
    "touch-up final reset",
)
text = text[:start] + touch_up + text[end:]

# Back button explicitly resets visibility for the next FFT session.
text = once(
    text,
    """        case UI_BUTTON_FFT_BACK:
            ui.mode = UI_MODE_RECORDER;
""",
    """        case UI_BUTTON_FFT_BACK:
            ui.fft_timeline_visible = false;
            ui.fft_timeline_dragging = false;
            ui.mode = UI_MODE_RECORDER;
""",
    "recorded FFT back button",
)

# -------------------------------------------------------------------------
# Automatic hide in UI_ProcessTouch
# -------------------------------------------------------------------------
auto_hide = '''
    if ((ui.mode == UI_MODE_RECORDED_FFT) &&
        ui.fft_timeline_visible &&
        !ui.fft_timeline_dragging &&
        ((now - ui.fft_timeline_last_interaction_ms) >=
         UI_FFT_TIMELINE_AUTO_HIDE_MS))
    {
        ui.fft_timeline_visible = false;
        ui.graph_dirty = true;
    }

'''
text = once(
    text,
    """    if (ui.controls_dirty)
    {
""",
    auto_hide + """    if (ui.controls_dirty)
    {
""",
    "UI touch redraw section",
)

# Add marker after geometry marker. The geometry marker appears once.
text = once(
    text,
    "/* RECORDED_FFT_TIMELINE_GEOMETRY_FIX */\n",
    """/* RECORDED_FFT_TIMELINE_GEOMETRY_FIX */
/* FFT_COLLAPSIBLE_TIMELINE_READINGS_PATCH */
""",
    "geometry feature marker",
)

# -------------------------------------------------------------------------
# Validate and write
# -------------------------------------------------------------------------
text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"

if text.count("{") != text.count("}"):
    fail("Brace balance failed")
if text.count("/*") != text.count("*/"):
    fail("Comment balance failed")
if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact generated")
if b"\x00" in text.encode("utf-8"):
    fail("Binary NUL generated")

for symbol in (
    MARKER,
    "fft_timeline_visible",
    "UI_FFT_TIMELINE_AUTO_HIDE_MS",
    "ui_recorded_fft_graph_height",
    "ui_draw_fft_readings",
    "ui_format_time_seconds",
    "UI FFT TIMELINE SHOW",
    "UI FFT TIMELINE HIDE",
):
    if symbol not in text:
        fail("Missing generated symbol: " + symbol)

# Ensure the existing release-only load action remains intact.
if "UI_ACTION_FFT_LOAD_SEGMENT" not in text:
    fail("Timeline release-load action was lost")

UI_C.write_text(text, encoding="utf-8")

print("Collapsible FFT timeline/readings patch applied successfully.")
print("Timeline is hidden by default, toggles on graph tap, and auto-hides in 3 s.")
print("SEG, TIME, PEAK frequency, and peak dBFS are drawn inside the graph.")
print("Full-height recorded FFT returns whenever the timeline is hidden.")
print("Timeline still loads only once on touch release.")
print("Next: make clean && make -j4")
