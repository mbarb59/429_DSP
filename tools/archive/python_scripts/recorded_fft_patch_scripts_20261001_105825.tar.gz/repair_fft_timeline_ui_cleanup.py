#!/usr/bin/env python3
"""Clean up recorded-FFT overlays and keep the timeline visible while dragging.

Changes only Core/Src/ui.c:
- removes the redundant standalone PK ... DB text from the peak marker
- keeps the consolidated SEG / time / PEAK reading overlay
- prevents auto-hide while the touchscreen is actively held
- refreshes the timeline timeout throughout timeline movement
- draws readings first and the timeline last
"""

from pathlib import Path
import re
import shutil

UI_C = Path("Core/Src/ui.c")
MARKER = "FFT_TIMELINE_UI_CLEANUP_PATCH"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


def function_range(text, signature, next_signature):
    start = text.find(signature)
    end = text.find(next_signature, start)
    if start < 0 or end < 0:
        fail("Could not isolate " + signature.strip())
    return start, end


if not UI_C.exists():
    fail("Run this script from the ~/429_DSP project root")

raw = UI_C.read_bytes()
if b"\x00" in raw:
    fail("Binary NUL found in Core/Src/ui.c")

text = raw.decode("utf-8")

if MARKER in text:
    fail("FFT timeline UI cleanup is already installed")

if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact found in Core/Src/ui.c")

for prerequisite in (
    "FFT_COLLAPSIBLE_TIMELINE_READINGS_PATCH",
    "ui_draw_fft_readings();",
    "ui_draw_fft_timeline();",
    "fft_timeline_visible",
    "fft_timeline_dragging",
    "UI_FFT_TIMELINE_AUTO_HIDE_MS",
    "ui_draw_db_peak_marker",
):
    if prerequisite not in text:
        fail("Missing prerequisite: " + prerequisite)

backup = UI_C.with_name(UI_C.name + ".before_fft_timeline_ui_cleanup")
if not backup.exists():
    shutil.copy2(UI_C, backup)

# -------------------------------------------------------------------------
# 1. Remove the old standalone PK/DB text block, retaining only the red marker.
# -------------------------------------------------------------------------
peak_start, peak_end = function_range(
    text,
    "static void ui_draw_db_peak_marker(void)\n",
    "static void ui_draw_grid(void)\n",
)
peak = text[peak_start:peak_end]

old_overlay = '''
    Display_FillRect(230, 36, 88, 18, COLOR_BLACK);
    Display_DrawString(230, 36, "PK", COLOR_WHITE, COLOR_BLACK);
    ui_draw_signed_db(250,
                      36,
                      FFT_GetPeakDbTenths(),
                      COLOR_YELLOW);
    Display_DrawString(294, 36, "DB", COLOR_GRAY, COLOR_BLACK);
'''

if peak.count(old_overlay) == 1:
    peak = peak.replace(old_overlay, "", 1)
else:
    # Accept small coordinate/spacing variations, but only inside this function.
    pattern = re.compile(
        r'\n[ \t]*Display_FillRect\(230,[^;]+;\n'
        r'[ \t]*Display_DrawString\(230,[^;]+"PK"[^;]+;\n'
        r'[ \t]*ui_draw_signed_db\(250,[\s\S]*?FFT_GetPeakDbTenths\(\),'
        r'[\s\S]*?;\n'
        r'[ \t]*Display_DrawString\(294,[^;]+"DB"[^;]+;\n'
    )
    peak, count = pattern.subn("\n", peak, count=1)
    if count != 1:
        fail("Could not find the redundant PK/DB overlay in ui_draw_db_peak_marker")

text = text[:peak_start] + peak + text[peak_end:]

# -------------------------------------------------------------------------
# 2. Ensure consolidated readings are drawn before timeline, timeline last.
# -------------------------------------------------------------------------
expected_order = '''            ui_draw_db_spectrum_trace();
            ui_draw_db_peak_marker();
            ui_draw_fft_readings();
            ui_draw_fft_timeline();
'''
if text.count(expected_order) != 1:
    fail("Recorded FFT overlay draw order differs from the expected active code")

# -------------------------------------------------------------------------
# 3. Keep auto-hide disabled for the entire active touch, not just drag state.
# -------------------------------------------------------------------------
auto_hide_old = '''    if ((ui.mode == UI_MODE_RECORDED_FFT) &&
        ui.fft_timeline_visible &&
        !ui.fft_timeline_dragging &&
        ((now - ui.fft_timeline_last_interaction_ms) >=
         UI_FFT_TIMELINE_AUTO_HIDE_MS))
'''
auto_hide_new = '''    if ((ui.mode == UI_MODE_RECORDED_FFT) &&
        ui.fft_timeline_visible &&
        !ui.touch_active &&
        !ui.fft_timeline_dragging &&
        ((now - ui.fft_timeline_last_interaction_ms) >=
         UI_FFT_TIMELINE_AUTO_HIDE_MS))
'''
text = once(text, auto_hide_old, auto_hide_new,
            "recorded FFT timeline auto-hide guard")

# -------------------------------------------------------------------------
# 4. Refresh interaction time whenever an active timeline touch is processed.
#    This guards against slow touch polling or movement below the drag threshold.
# -------------------------------------------------------------------------
move_start, move_end = function_range(
    text,
    "static void ui_handle_touch_move(const STMPE811_TouchData *touch)\n",
    "static void ui_handle_touch_up(void)\n",
)
move = text[move_start:move_end]

move_anchor = '''    if ((total_x > UI_TAP_MOVE_LIMIT) ||
        (total_y > UI_TAP_MOVE_LIMIT))
    {
        ui.dragging = true;
    }

'''
move_replacement = move_anchor + '''    if ((ui.mode == UI_MODE_RECORDED_FFT) &&
        ui.fft_timeline_visible &&
        ui.fft_timeline_dragging)
    {
        ui.fft_timeline_last_interaction_ms = HAL_GetTick();
    }

'''
move = once(move, move_anchor, move_replacement,
            "touch-move drag-threshold block")
text = text[:move_start] + move + text[move_end:]

# -------------------------------------------------------------------------
# 5. Add feature marker beside the collapsible timeline marker.
# -------------------------------------------------------------------------
text = once(
    text,
    "/* FFT_COLLAPSIBLE_TIMELINE_READINGS_PATCH */\n",
    """/* FFT_COLLAPSIBLE_TIMELINE_READINGS_PATCH */
/* FFT_TIMELINE_UI_CLEANUP_PATCH */
""",
    "collapsible timeline marker",
)

text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"

if text.count("{") != text.count("}"):
    fail("Brace balance failed")
if text.count("/*") != text.count("*/"):
    fail("Comment balance failed")
if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact generated")
if b"\x00" in text.encode("utf-8"):
    fail("Binary NUL generated")

for required in (
    MARKER,
    "!ui.touch_active",
    "ui_draw_fft_readings();",
    "ui_draw_fft_timeline();",
    "ui.fft_timeline_last_interaction_ms = HAL_GetTick();",
):
    if required not in text:
        fail("Missing generated symbol: " + required)

# The separate old top label must be gone, but the consolidated reading remains.
peak_start, peak_end = function_range(
    text,
    "static void ui_draw_db_peak_marker(void)\n",
    "static void ui_draw_grid(void)\n",
)
peak = text[peak_start:peak_end]
if 'Display_DrawString(230, 36, "PK"' in peak:
    fail("Redundant PK label remains")
if "static void ui_draw_fft_readings(void)" not in text:
    fail("Consolidated FFT readings function is missing")

UI_C.write_text(text, encoding="utf-8")

print("FFT timeline UI cleanup patch applied successfully.")
print("Removed the redundant standalone PK/DB overlay.")
print("Timeline auto-hide is suspended during the complete active touch.")
print("Timeline interaction timeout is refreshed throughout dragging.")
print("Consolidated readings remain and the timeline is drawn last.")
print("Next: make clean && make -j4")
