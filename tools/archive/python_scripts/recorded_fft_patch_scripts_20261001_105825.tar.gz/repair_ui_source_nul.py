#!/usr/bin/env python3
"""Repair accidental binary NUL bytes in Core/Src/ui.c.

A prior generated patch may have written an actual 0x00 byte where the C source
should contain the two printable characters backslash-zero in a character
literal. This script backs up ui.c, reports the offsets, replaces each 0x00 with
\\0, then validates UTF-8, brace balance, comment balance, and HTML artifacts.
"""

from pathlib import Path
import re
import shutil

PATH = Path("Core/Src/ui.c")
BACKUP = PATH.with_name(PATH.name + ".before_nul_repair")

if not PATH.exists():
    raise SystemExit("Run this script from the ~/429_DSP project root")

data = PATH.read_bytes()
count = data.count(b"\x00")

if count == 0:
    raise SystemExit("No binary NUL bytes found in Core/Src/ui.c")

if not BACKUP.exists():
    shutil.copy2(PATH, BACKUP)

print(f"Binary NUL bytes found: {count}")
for index, byte in enumerate(data):
    if byte == 0:
        left = max(0, index - 32)
        right = min(len(data), index + 33)
        context = data[left:right].replace(b"\n", b"\\n")
        print(f"Offset {index}: {context!r}")

repaired = data.replace(b"\x00", b"\\0")

try:
    text = repaired.decode("utf-8")
except UnicodeDecodeError as exc:
    raise SystemExit(f"UTF-8 validation failed after repair: {exc}")

if text.count("{") != text.count("}"):
    raise SystemExit("Brace balance failed after repair; source not written")
if text.count("/*") != text.count("*/"):
    raise SystemExit("Comment balance failed after repair; source not written")
if re.search(r"&(lt|gt|amp);|<br", text):
    raise SystemExit("HTML artifact detected after repair; source not written")
if b"\x00" in repaired:
    raise SystemExit("NUL validation failed after repair; source not written")

PATH.write_bytes(repaired)

print("Binary NUL repair applied successfully.")
print(f"Backup: {BACKUP}")
print("Replacement: each 0x00 byte became the printable C escape \\0")
print("Next: python3 -m py_compile patch_tft_fft_scan_export.py")
print("Then: python3 patch_tft_fft_scan_export.py")
