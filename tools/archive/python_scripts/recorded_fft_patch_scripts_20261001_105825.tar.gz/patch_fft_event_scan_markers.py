#!/usr/bin/env python3
"""Add UART fftscan and strongest-event markers to the recorded FFT timeline."""

from pathlib import Path
import re
import shutil

WAV_H = Path("Core/Inc/wav_fft_viewer.h")
WAV_C = Path("Core/Src/wav_fft_viewer.c")
UI_C = Path("Core/Src/ui.c")
MAIN_C = Path("Core/Src/main.c")
MARKER = "FFT_EVENT_SCAN_MARKERS_PATCH"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


def backup(path):
    target = path.with_name(path.name + ".before_fft_event_scan")
    if not target.exists():
        shutil.copy2(path, target)


paths = (WAV_H, WAV_C, UI_C, MAIN_C)
texts = {}
for path in paths:
    if not path.exists():
        fail("Missing required file: " + str(path))
    raw = path.read_bytes()
    if b"\x00" in raw:
        fail("Binary NUL found in " + str(path))
    text = raw.decode("utf-8")
    if re.search(r"&(lt|gt|amp);|<br", text):
        fail("HTML artifact found in " + str(path))
    if MARKER in text:
        fail("FFT event scan is already installed in " + str(path))
    texts[path] = text

wav_h, wav_c, ui_c, main_c = [texts[p] for p in paths]
combined = wav_h + wav_c + ui_c + main_c
for required in (
    "WavFftViewer_LoadSegment",
    "WavFftViewer_GetInfo",
    "FFT_GetPeakDbTenths",
    "FFT_GetPeakFrequency",
    "static void ui_draw_fft_timeline(void)",
    "Console_RunFftExport",
    'strcmp(command, "fftexport")',
):
    if required not in combined:
        fail("Missing prerequisite: " + required)

for path in paths:
    backup(path)

# -------------------------------------------------------------------------
# WAV viewer public event API
# -------------------------------------------------------------------------
wav_h = once(
    wav_h,
    "#define WAV_FFT_VIEWER_SIZE  2048U\n",
    """#define WAV_FFT_VIEWER_SIZE  2048U
#define WAV_FFT_SCAN_MAX_EVENTS  5U
#define WAV_FFT_SCAN_STEP_SEGMENTS  4U
#define WAV_FFT_SCAN_MIN_SEPARATION_SEGMENTS  12U
""",
    "WAV FFT viewer size definition",
)

wav_h = once(
    wav_h,
    """typedef struct
{
    bool active;
""",
    """typedef struct
{
    bool valid;
    uint32_t segment_index;
    uint32_t time_ms;
    uint32_t peak_frequency_hz;
    int16_t peak_db_tenths;
} WavFftPeakEvent;

typedef struct
{
    bool active;
""",
    "WAV FFT info structure",
)

wav_h = once(
    wav_h,
    "const WavFftViewerInfo *WavFftViewer_GetInfo(void);\n",
    """const WavFftViewerInfo *WavFftViewer_GetInfo(void);

/* FFT_EVENT_SCAN_MARKERS_PATCH */
FRESULT WavFftViewer_ScanEvents(void);
uint32_t WavFftViewer_GetEventCount(void);
const WavFftPeakEvent *WavFftViewer_GetEvent(uint32_t index);
""",
    "WAV FFT info accessor",
)

# -------------------------------------------------------------------------
# WAV viewer scan implementation
# -------------------------------------------------------------------------
wav_c = once(
    wav_c,
    "static uint32_t previous_fft_size;\n",
    """static uint32_t previous_fft_size;
static WavFftPeakEvent peak_events[WAV_FFT_SCAN_MAX_EVENTS];
static uint32_t peak_event_count;
""",
    "WAV FFT previous size state",
)

wav_c = once(
    wav_c,
    """    memset(&info, 0, sizeof(info));
    memset(active_filename, 0, sizeof(active_filename));
""",
    """    memset(&info, 0, sizeof(info));
    memset(active_filename, 0, sizeof(active_filename));
    memset(peak_events, 0, sizeof(peak_events));
    peak_event_count = 0U;
""",
    "WAV FFT initialization",
)

scan_impl = r'''static uint32_t event_segment_distance(uint32_t a, uint32_t b)
{
    return (a >= b) ? (a - b) : (b - a);
}

static void insert_peak_event(const WavFftPeakEvent *candidate)
{
    uint32_t index;

    for (index = 0U; index < peak_event_count; index++)
    {
        if (event_segment_distance(candidate->segment_index,
                                   peak_events[index].segment_index) <
            WAV_FFT_SCAN_MIN_SEPARATION_SEGMENTS)
        {
            if (candidate->peak_db_tenths <=
                peak_events[index].peak_db_tenths)
            {
                return;
            }

            peak_events[index] = *candidate;

            while ((index > 0U) &&
                   (peak_events[index].peak_db_tenths >
                    peak_events[index - 1U].peak_db_tenths))
            {
                WavFftPeakEvent temporary = peak_events[index - 1U];
                peak_events[index - 1U] = peak_events[index];
                peak_events[index] = temporary;
                index--;
            }
            return;
        }
    }

    if (peak_event_count < WAV_FFT_SCAN_MAX_EVENTS)
    {
        index = peak_event_count++;
    }
    else
    {
        if (candidate->peak_db_tenths <=
            peak_events[peak_event_count - 1U].peak_db_tenths)
        {
            return;
        }
        index = peak_event_count - 1U;
    }

    peak_events[index] = *candidate;
    while ((index > 0U) &&
           (peak_events[index].peak_db_tenths >
            peak_events[index - 1U].peak_db_tenths))
    {
        WavFftPeakEvent temporary = peak_events[index - 1U];
        peak_events[index - 1U] = peak_events[index];
        peak_events[index] = temporary;
        index--;
    }
}

FRESULT WavFftViewer_ScanEvents(void)
{
    FRESULT result = FR_OK;
    uint32_t original_segment;

    if (!info.active || (info.segment_count == 0U))
    {
        return FR_INVALID_OBJECT;
    }

    original_segment = info.segment_index;
    memset(peak_events, 0, sizeof(peak_events));
    peak_event_count = 0U;

    for (uint32_t segment = 0U;
         segment < info.segment_count;
         segment += WAV_FFT_SCAN_STEP_SEGMENTS)
    {
        WavFftPeakEvent candidate;

        result = load_segment(segment);
        if (result != FR_OK)
        {
            break;
        }

        candidate.valid = true;
        candidate.segment_index = segment;
        candidate.time_ms = info.segment_time_ms;
        candidate.peak_frequency_hz = FFT_GetPeakFrequency();
        candidate.peak_db_tenths = FFT_GetPeakDbTenths();
        insert_peak_event(&candidate);
    }

    if ((result == FR_OK) && (peak_event_count != 0U))
    {
        /* Refine each coarse event within +/- one coarse scan step. */
        WavFftPeakEvent coarse[WAV_FFT_SCAN_MAX_EVENTS];
        uint32_t coarse_count = peak_event_count;
        memcpy(coarse, peak_events, sizeof(coarse));
        memset(peak_events, 0, sizeof(peak_events));
        peak_event_count = 0U;

        for (uint32_t event = 0U; event < coarse_count; event++)
        {
            uint32_t first = (coarse[event].segment_index >
                              WAV_FFT_SCAN_STEP_SEGMENTS) ?
                coarse[event].segment_index - WAV_FFT_SCAN_STEP_SEGMENTS : 0U;
            uint32_t last = coarse[event].segment_index +
                            WAV_FFT_SCAN_STEP_SEGMENTS;

            if (last >= info.segment_count)
            {
                last = info.segment_count - 1U;
            }

            for (uint32_t segment = first; segment <= last; segment++)
            {
                WavFftPeakEvent candidate;
                result = load_segment(segment);
                if (result != FR_OK)
                {
                    break;
                }

                candidate.valid = true;
                candidate.segment_index = segment;
                candidate.time_ms = info.segment_time_ms;
                candidate.peak_frequency_hz = FFT_GetPeakFrequency();
                candidate.peak_db_tenths = FFT_GetPeakDbTenths();
                insert_peak_event(&candidate);
            }

            if (result != FR_OK)
            {
                break;
            }
        }
    }

    if ((result == FR_OK) && (peak_event_count != 0U))
    {
        result = load_segment(peak_events[0].segment_index);
    }
    else
    {
        (void)load_segment(original_segment);
    }

    return result;
}

uint32_t WavFftViewer_GetEventCount(void)
{
    return peak_event_count;
}

const WavFftPeakEvent *WavFftViewer_GetEvent(uint32_t index)
{
    if (index >= peak_event_count)
    {
        return NULL;
    }

    return &peak_events[index];
}

'''

wav_c = once(
    wav_c,
    "void WavFftViewer_End(void)\n",
    scan_impl + "void WavFftViewer_End(void)\n",
    "WAV FFT end implementation",
)

# -------------------------------------------------------------------------
# UI timeline event markers
# -------------------------------------------------------------------------
ui_c = once(
    ui_c,
    "/* FFT_TIMELINE_UI_CLEANUP_PATCH */\n",
    """/* FFT_TIMELINE_UI_CLEANUP_PATCH */
/* FFT_EVENT_SCAN_MARKERS_PATCH */
""",
    "timeline cleanup marker",
)

marker_block = '''
    for (uint32_t event_index = 0U;
         event_index < WavFftViewer_GetEventCount();
         event_index++)
    {
        const WavFftPeakEvent *event =
            WavFftViewer_GetEvent(event_index);
        int32_t event_x;
        uint16_t event_color;

        if ((event == NULL) || !event->valid)
        {
            continue;
        }

        if (info->segment_count <= 1U)
        {
            event_x = UI_FFT_TIMELINE_X;
        }
        else
        {
            event_x = UI_FFT_TIMELINE_X + (int32_t)(
                ((uint64_t)event->segment_index *
                 (UI_FFT_TIMELINE_WIDTH - 1U)) /
                (info->segment_count - 1U));
        }

        event_color = (event_index == 0U) ? COLOR_RED : COLOR_YELLOW;
        Display_DrawLine(event_x,
                         UI_FFT_TIMELINE_Y + 4,
                         event_x,
                         UI_FFT_TIMELINE_LINE_Y - 2,
                         event_color);
        Display_DrawLine(event_x - 2,
                         UI_FFT_TIMELINE_Y + 4,
                         event_x + 2,
                         UI_FFT_TIMELINE_Y + 4,
                         event_color);
    }

'''
ui_c = once(
    ui_c,
    """    Display_DrawLine(UI_FFT_TIMELINE_X,
                     UI_FFT_TIMELINE_LINE_Y,
""",
    marker_block + """    Display_DrawLine(UI_FFT_TIMELINE_X,
                     UI_FFT_TIMELINE_LINE_Y,
""",
    "timeline baseline drawing",
)

# -------------------------------------------------------------------------
# Main UART command
# -------------------------------------------------------------------------
main_c = once(
    main_c,
    "static void Console_RunFftExport(void);\n",
    """static void Console_RunFftExport(void);
static void Console_RunFftScan(void);
""",
    "FFT export declaration",
)

main_c = once(
    main_c,
    "/* FFTEXPORT_CSV_PATCH */\n",
    """/* FFTEXPORT_CSV_PATCH */
/* FFT_EVENT_SCAN_MARKERS_PATCH */
""",
    "FFT export feature marker",
)

scan_console = r'''static void Console_RunFftScan(void)
{
    const WavFftViewerInfo *info = WavFftViewer_GetInfo();
    FRESULT result;

    UART_SendString("FFT Event Scan\r\n");
    UART_SendString("--------------\r\n");

    if (Capture_IsRecorderActive())
    {
        UART_SendString("FFT scan blocked: recorder active\r\n");
        return;
    }

    if ((info == NULL) || !info->active)
    {
        UART_SendString(
            "FFT scan blocked: open a recorded WAV FFT first\r\n");
        return;
    }

    UART_SendString("Source File    = ");
    UART_SendString(RecordingCatalog_GetSelected());
    UART_SendString("\r\nSegments       = ");
    UART_SendDec(info->segment_count);
    UART_SendString("\r\nScan Step      = ");
    UART_SendDec(WAV_FFT_SCAN_STEP_SEGMENTS);
    UART_SendString("\r\nScanning...\r\n");

    result = WavFftViewer_ScanEvents();

    UART_SendString("Events Found   = ");
    UART_SendDec(WavFftViewer_GetEventCount());
    UART_SendString("\r\n");

    if (result == FR_OK)
    {
        for (uint32_t index = 0U;
             index < WavFftViewer_GetEventCount();
             index++)
        {
            const WavFftPeakEvent *event = WavFftViewer_GetEvent(index);
            if (event == NULL)
            {
                continue;
            }

            UART_SendString("Event ");
            UART_SendDec(index + 1U);
            UART_SendString(": SEG=");
            UART_SendDec(event->segment_index + 1U);
            UART_SendString(" TIME_MS=");
            UART_SendDec(event->time_ms);
            UART_SendString(" PEAK_HZ=");
            UART_SendDec(event->peak_frequency_hz);
            UART_SendString(" DB_X10=");
            if (event->peak_db_tenths < 0)
            {
                UART_SendChar('-');
                UART_SendDec((uint32_t)(-event->peak_db_tenths));
            }
            else
            {
                UART_SendDec((uint32_t)event->peak_db_tenths);
            }
            UART_SendString("\r\n");
        }

        UI_ShowRecordedFft();
    }

    UART_SendString("Scan Result    = ");
    UART_SendDec((uint32_t)result);
    UART_SendString((result == FR_OK) ? "  PASS\r\n" : "  FAIL\r\n");
}

'''

main_c = once(
    main_c,
    "static void Console_RunFftExport(void)\n",
    scan_console + "static void Console_RunFftExport(void)\n",
    "FFT export implementation",
)

main_c = once(
    main_c,
    """    else if (strcmp(command, "fftexport") == 0)
    {
        Console_RunFftExport();
    }
""",
    """    else if (strcmp(command, "fftexport") == 0)
    {
        Console_RunFftExport();
    }
    else if (strcmp(command, "fftscan") == 0)
    {
        Console_RunFftScan();
    }
""",
    "fftexport command block",
)

# -------------------------------------------------------------------------
# Validate and write
# -------------------------------------------------------------------------
outputs = []
for path, text in ((WAV_H, wav_h), (WAV_C, wav_c),
                   (UI_C, ui_c), (MAIN_C, main_c)):
    text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"
    if text.count("{") != text.count("}"):
        fail("Brace mismatch in " + str(path))
    if text.count("/*") != text.count("*/"):
        fail("Comment mismatch in " + str(path))
    if re.search(r"&(lt|gt|amp);|<br", text):
        fail("HTML artifact generated in " + str(path))
    if b"\x00" in text.encode("utf-8"):
        fail("Binary NUL generated in " + str(path))
    outputs.append((path, text))

joined = "\n".join(text for _, text in outputs)
for required in (
    MARKER,
    "WavFftViewer_ScanEvents",
    "WavFftViewer_GetEventCount",
    "WavFftViewer_GetEvent",
    'strcmp(command, "fftscan")',
    "Console_RunFftScan",
    "WAV_FFT_SCAN_MIN_SEPARATION_SEGMENTS",
):
    if required not in joined:
        fail("Missing generated symbol: " + required)

for path, text in outputs:
    path.write_text(text, encoding="utf-8")

print("FFT strongest-event scan and timeline markers applied successfully.")
print("UART command: fftscan")
print("Quick scan uses every fourth segment, then refines around candidates.")
print("Five separated strongest events are retained and marked on the timeline.")
print("The viewer jumps to the strongest event after a successful scan.")
print("No CSV is written automatically; use fftexport on the selected event.")
print("Next: make clean && make -j4")
