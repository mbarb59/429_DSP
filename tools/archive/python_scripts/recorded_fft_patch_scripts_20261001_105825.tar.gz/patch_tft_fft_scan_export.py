#!/usr/bin/env python3
"""Replace recorded-FFT FULL/PEAK controls with TFT SCAN/EXPORT actions."""

from pathlib import Path
import re
import shutil

UI_H = Path("Core/Inc/ui.h")
UI_C = Path("Core/Src/ui.c")
MAIN_C = Path("Core/Src/main.c")
MARKER = "TFT_FFT_SCAN_EXPORT_PATCH"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


for path in (UI_H, UI_C, MAIN_C):
    if not path.exists():
        fail("Missing required file: " + str(path))
    raw = path.read_bytes()
    if b"\x00" in raw:
        fail("Binary NUL found in " + str(path))

ui_h = UI_H.read_text(encoding="utf-8")
ui_c = UI_C.read_text(encoding="utf-8")
main_c = MAIN_C.read_text(encoding="utf-8")

if MARKER in (ui_h + ui_c + main_c):
    fail("TFT SCAN/EXPORT controls are already installed")

for path, text in ((UI_H, ui_h), (UI_C, ui_c), (MAIN_C, main_c)):
    if re.search(r"&(lt|gt|amp);|<br", text):
        fail("HTML artifact found in " + str(path))

for required in (
    "UI_ACTION_FFT_PREVIOUS",
    "UI_ACTION_FFT_NEXT",
    "UI_BUTTON_FFT_FULL",
    "UI_BUTTON_FFT_PEAK",
    "Console_RunFftScan",
    "Console_RunFftExport",
    "CSV_SAFETY_GUARDS_MAIN_PATCH",
):
    if required not in (ui_h + ui_c + main_c):
        fail("Missing prerequisite: " + required)

for path in (UI_H, UI_C, MAIN_C):
    backup = path.with_name(path.name + ".before_tft_fft_scan_export")
    if not backup.exists():
        shutil.copy2(path, backup)

# Public UI actions consumed by main.c.
ui_h = once(
    ui_h,
    """    UI_ACTION_FFT_PREVIOUS,
    UI_ACTION_FFT_NEXT,
    UI_ACTION_FFT_LOAD_SEGMENT,
""",
    """    UI_ACTION_FFT_PREVIOUS,
    UI_ACTION_FFT_NEXT,
    UI_ACTION_FFT_SCAN,
    UI_ACTION_FFT_EXPORT,
    UI_ACTION_FFT_LOAD_SEGMENT,
""",
    "recorded FFT action enum",
)

# Internal button identities.
ui_c = once(
    ui_c,
    """    UI_BUTTON_FFT_PREVIOUS,
    UI_BUTTON_FFT_NEXT,
    UI_BUTTON_FFT_FULL,
    UI_BUTTON_FFT_PEAK,
""",
    """    UI_BUTTON_FFT_PREVIOUS,
    UI_BUTTON_FFT_NEXT,
    UI_BUTTON_FFT_SCAN,
    UI_BUTTON_FFT_EXPORT,
""",
    "recorded FFT button enum",
)

# Button labels. Existing button colors remain unchanged.
ui_c = once(
    ui_c,
    """        Display_DrawString(144, 12, "NEXT", COLOR_BLACK, COLOR_GREEN);
        Display_DrawString(208, 12, "FULL", COLOR_BLACK, COLOR_YELLOW);
        Display_DrawString(278, 12, "PEAK", COLOR_BLACK, COLOR_MAGENTA);
""",
    """        Display_DrawString(144, 12, "NEXT", COLOR_BLACK, COLOR_GREEN);
        Display_DrawString(208, 12, "SCAN", COLOR_BLACK, COLOR_YELLOW);
        Display_DrawString(266, 12, "EXPORT", COLOR_BLACK, COLOR_MAGENTA);
""",
    "recorded FFT control labels",
)

# Recorded FFT hit testing.
ui_c = once(
    ui_c,
    """        if (x < 256U)
        {
            return UI_BUTTON_FFT_FULL;
        }
        if (x < DISPLAY_WIDTH)
        {
            return UI_BUTTON_FFT_PEAK;
        }
""",
    """        if (x < 256U)
        {
            return UI_BUTTON_FFT_SCAN;
        }
        if (x < DISPLAY_WIDTH)
        {
            return UI_BUTTON_FFT_EXPORT;
        }
""",
    "recorded FFT button hit test",
)

# Button execution now emits deferred main-loop actions.
ui_c = once(
    ui_c,
    """        case UI_BUTTON_FFT_FULL:
            ui_apply_full_span();
            ui.graph_dirty = true;
            UART_SendString("UI RECORDED FFT FULL\\r\\n");
            break;

        case UI_BUTTON_FFT_PEAK:
            ui_center_on_peak();
            ui.graph_dirty = true;
            UART_SendString("UI RECORDED FFT PEAK\\r\\n");
            break;
""",
    """        case UI_BUTTON_FFT_SCAN:
            ui.pending_action = UI_ACTION_FFT_SCAN;
            UART_SendString("UI RECORDED FFT SCAN REQUEST\\r\\n");
            break;

        case UI_BUTTON_FFT_EXPORT:
            ui.pending_action = UI_ACTION_FFT_EXPORT;
            UART_SendString("UI RECORDED FFT EXPORT REQUEST\\r\\n");
            break;
""",
    "recorded FFT FULL/PEAK execution cases",
)

# Source marker.
ui_c = once(
    ui_c,
    "/* FFT_EVENT_SCAN_MARKERS_PATCH */\n",
    """/* FFT_EVENT_SCAN_MARKERS_PATCH */
/* TFT_FFT_SCAN_EXPORT_PATCH */
""",
    "FFT event marker in UI",
)

# Foreground action processing in main.c. Insert before load-segment action.
main_cases = '''        case UI_ACTION_FFT_SCAN:
            if (!RecordingCatalog_SelectedIsWav())
            {
                UART_SendString("FFT scan blocked: select a WAV file\\r\\n");
                break;
            }
            Console_RunFftScan();
            break;

        case UI_ACTION_FFT_EXPORT:
            if (!RecordingCatalog_SelectedIsWav())
            {
                UART_SendString("FFT export blocked: select a WAV file\\r\\n");
                break;
            }
            Console_RunFftExport();
            break;

'''
main_c = once(
    main_c,
    "        case UI_ACTION_FFT_LOAD_SEGMENT:\n",
    main_cases + "        case UI_ACTION_FFT_LOAD_SEGMENT:\n",
    "recorded FFT load-segment action case",
)

main_c = once(
    main_c,
    "/* CSV_SAFETY_GUARDS_MAIN_PATCH */\n",
    """/* CSV_SAFETY_GUARDS_MAIN_PATCH */
/* TFT_FFT_SCAN_EXPORT_PATCH */
""",
    "CSV safety marker in main",
)

outputs = []
for path, text in ((UI_H, ui_h), (UI_C, ui_c), (MAIN_C, main_c)):
    text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"
    if text.count("{") != text.count("}"):
        fail("Brace mismatch in " + str(path))
    if text.count("/*") != text.count("*/"):
        fail("Comment mismatch in " + str(path))
    if re.search(r"&(lt|gt|amp);|<br", text):
        fail("HTML artifact generated in " + str(path))
    outputs.append((path, text))

joined = "\n".join(text for _, text in outputs)
for required in (
    MARKER,
    "UI_ACTION_FFT_SCAN",
    "UI_ACTION_FFT_EXPORT",
    "UI_BUTTON_FFT_SCAN",
    "UI_BUTTON_FFT_EXPORT",
    '"SCAN"',
    '"EXPORT"',
    "Console_RunFftScan();",
    "Console_RunFftExport();",
):
    if required not in joined:
        fail("Missing generated item: " + required)

for path, text in outputs:
    path.write_text(text, encoding="utf-8")

print("TFT recorded-FFT SCAN and EXPORT controls applied successfully.")
print("Recorded FFT buttons are now BACK, PREV, NEXT, SCAN, EXPORT.")
print("SCAN calls the existing strongest-event scan.")
print("EXPORT writes the current segment to the matching CSV.")
print("Next: make clean && make -j4")
