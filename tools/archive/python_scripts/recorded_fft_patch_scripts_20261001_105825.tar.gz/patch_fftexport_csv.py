#!/usr/bin/env python3
"""Add the UART command fftexport for the active recorded-WAV FFT segment.

The command creates/replaces a CSV with the same base name as the selected WAV:
  REC0002.WAV -> REC0002.CSV

The original WAV is never modified. Formatting is freestanding and does not use
stdio, snprintf, malloc, or floating-point text conversion.
"""

from pathlib import Path
import re
import shutil

MAIN_C = Path("Core/Src/main.c")
MARKER = "FFTEXPORT_CSV_PATCH"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


if not MAIN_C.exists():
    fail("Run this script from the ~/429_DSP project root")

raw = MAIN_C.read_bytes()
if b"\x00" in raw:
    fail("Binary NUL found in Core/Src/main.c")

text = raw.decode("utf-8")

if MARKER in text:
    fail("fftexport CSV support is already installed")

if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact found in Core/Src/main.c")

for required in (
    "static void Console_ProcessCommand(char *command);",
    "static void Console_ProcessCommand(char *command)\n",
    'else if (strcmp(command, "recstatus") == 0)',
    "RecordingCatalog_GetSelected()",
    "WavFftViewer_Begin",
    "FFT_GetMagnitude",
    "Capture_IsRecorderActive",
):
    if required not in text:
        fail("Missing prerequisite: " + required)

backup = MAIN_C.with_name(MAIN_C.name + ".before_fftexport_csv")
if not backup.exists():
    shutil.copy2(MAIN_C, backup)

# Add a feature marker near the existing recorded FFT marker.
text = once(
    text,
    "/* UI_RECORDED_FFT_PATCH */\n",
    """/* UI_RECORDED_FFT_PATCH */
/* FFTEXPORT_CSV_PATCH */
""",
    "recorded FFT feature marker",
)

# Add the function declaration beside the command parser declaration.
text = once(
    text,
    "static void Console_ProcessCommand(char *command);\n",
    """static void Console_ProcessCommand(char *command);
static void Console_RunFftExport(void);
""",
    "command parser declaration",
)

helpers = r'''#define FFTEXPORT_TEXT_CAPACITY  160U

static uint32_t FftExport_AppendText(char *buffer,
                                     uint32_t capacity,
                                     uint32_t position,
                                     const char *value)
{
    if ((buffer == NULL) || (value == NULL) || (capacity == 0U))
    {
        return position;
    }

    while ((*value != '\0') && ((position + 1U) < capacity))
    {
        buffer[position++] = *value++;
    }

    buffer[position] = '\0';
    return position;
}

static uint32_t FftExport_AppendUint(char *buffer,
                                     uint32_t capacity,
                                     uint32_t position,
                                     uint32_t value)
{
    char reverse[10];
    uint32_t count = 0U;

    do
    {
        reverse[count++] = (char)('0' + (value % 10U));
        value /= 10U;
    }
    while ((value != 0U) && (count < sizeof(reverse)));

    while ((count != 0U) && ((position + 1U) < capacity))
    {
        buffer[position++] = reverse[--count];
    }

    buffer[position] = '\0';
    return position;
}

static uint32_t FftExport_AppendInt(char *buffer,
                                    uint32_t capacity,
                                    uint32_t position,
                                    int32_t value)
{
    uint32_t magnitude;

    if (value < 0)
    {
        position = FftExport_AppendText(buffer,
                                        capacity,
                                        position,
                                        "-");
        magnitude = (uint32_t)(-(value + 1)) + 1U;
    }
    else
    {
        magnitude = (uint32_t)value;
    }

    return FftExport_AppendUint(buffer,
                                capacity,
                                position,
                                magnitude);
}

static bool FftExport_Write(FIL *file,
                            const char *text,
                            FRESULT *result)
{
    UINT bytes_written = 0U;
    UINT length = 0U;

    if ((file == NULL) || (text == NULL) || (result == NULL))
    {
        return false;
    }

    while (text[length] != '\0')
    {
        length++;
    }

    *result = f_write(file, text, length, &bytes_written);
    return (*result == FR_OK) && (bytes_written == length);
}

static bool FftExport_WriteKeyUint(FIL *file,
                                   const char *key,
                                   uint32_t value,
                                   FRESULT *result)
{
    char line[FFTEXPORT_TEXT_CAPACITY];
    uint32_t position = 0U;

    line[0] = '\0';
    position = FftExport_AppendText(line, sizeof(line), position, key);
    position = FftExport_AppendText(line, sizeof(line), position, ",");
    position = FftExport_AppendUint(line, sizeof(line), position, value);
    (void)FftExport_AppendText(line, sizeof(line), position, "\r\n");

    return FftExport_Write(file, line, result);
}

static bool FftExport_WriteKeyInt(FIL *file,
                                  const char *key,
                                  int32_t value,
                                  FRESULT *result)
{
    char line[FFTEXPORT_TEXT_CAPACITY];
    uint32_t position = 0U;

    line[0] = '\0';
    position = FftExport_AppendText(line, sizeof(line), position, key);
    position = FftExport_AppendText(line, sizeof(line), position, ",");
    position = FftExport_AppendInt(line, sizeof(line), position, value);
    (void)FftExport_AppendText(line, sizeof(line), position, "\r\n");

    return FftExport_Write(file, line, result);
}

static bool FftExport_MakeFilename(const char *wav_name,
                                   char *csv_name,
                                   uint32_t capacity)
{
    uint32_t position = 0U;

    if ((wav_name == NULL) || (wav_name[0] == '\0') ||
        (csv_name == NULL) || (capacity < 5U))
    {
        return false;
    }

    while ((wav_name[position] != '\0') &&
           (wav_name[position] != '.') &&
           ((position + 5U) < capacity))
    {
        csv_name[position] = wav_name[position];
        position++;
    }

    if ((position == 0U) || ((position + 5U) > capacity))
    {
        return false;
    }

    csv_name[position++] = '.';
    csv_name[position++] = 'C';
    csv_name[position++] = 'S';
    csv_name[position++] = 'V';
    csv_name[position] = '\0';
    return true;
}

static void Console_RunFftExport(void)
{
    const WavFftViewerInfo *info = WavFftViewer_GetInfo();
    const char *source_name = RecordingCatalog_GetSelected();
    FIL file;
    FRESULT result = FR_OK;
    char output_name[13];
    char line[FFTEXPORT_TEXT_CAPACITY];
    uint32_t bin_count;
    uint32_t bin_width_millihz;
    uint32_t bins_written = 0U;
    bool file_open = false;
    bool success = false;

    UART_SendString("FFT CSV Export\r\n");
    UART_SendString("--------------\r\n");

    if (Capture_IsRecorderActive())
    {
        UART_SendString("FFT export blocked: recorder active\r\n");
        return;
    }

    if ((info == NULL) || !info->active || !FFT_IsValid())
    {
        UART_SendString(
            "FFT export blocked: open a recorded WAV FFT first\r\n");
        return;
    }

    if (!FftExport_MakeFilename(source_name,
                                output_name,
                                sizeof(output_name)))
    {
        UART_SendString("FFT export blocked: invalid WAV filename\r\n");
        return;
    }

    result = f_open(&file, output_name, FA_CREATE_ALWAYS | FA_WRITE);
    if (result != FR_OK)
    {
        UART_SendString("FFT export open failed, FatFs = ");
        UART_SendDec((uint32_t)result);
        UART_SendString("\r\n");
        return;
    }
    file_open = true;

    success = FftExport_Write(&file,
                              "429_DSP FFT EXPORT\r\n",
                              &result);

    if (success)
    {
        uint32_t position = 0U;
        line[0] = '\0';
        position = FftExport_AppendText(line, sizeof(line), position,
                                        "Source File,");
        position = FftExport_AppendText(line, sizeof(line), position,
                                        source_name);
        (void)FftExport_AppendText(line, sizeof(line), position, "\r\n");
        success = FftExport_Write(&file, line, &result);
    }

    if (success) success = FftExport_WriteKeyUint(
        &file, "Segment", info->segment_index + 1U, &result);
    if (success) success = FftExport_WriteKeyUint(
        &file, "Segment Count", info->segment_count, &result);
    if (success) success = FftExport_WriteKeyUint(
        &file, "Segment Time ms", info->segment_time_ms, &result);
    if (success) success = FftExport_WriteKeyUint(
        &file, "Sample Rate Hz", info->sample_rate, &result);
    if (success) success = FftExport_WriteKeyUint(
        &file, "FFT Size", FFT_GetSize(), &result);
    if (success) success = FftExport_WriteKeyUint(
        &file, "Bin Width mHz", FFT_GetBinWidthMilliHz(), &result);
    if (success) success = FftExport_WriteKeyUint(
        &file, "Peak Frequency Hz", FFT_GetPeakFrequency(), &result);
    if (success) success = FftExport_WriteKeyInt(
        &file, "Peak Level dBFS x10", FFT_GetPeakDbTenths(), &result);
    if (success) success = FftExport_Write(
        &file,
        "\r\nBin,Frequency mHz,Magnitude Counts,Level dBFS x10\r\n",
        &result);

    bin_count = FFT_GetBinCount();
    bin_width_millihz = FFT_GetBinWidthMilliHz();

    for (uint32_t bin = 1U; success && (bin < bin_count); bin++)
    {
        uint32_t position = 0U;
        uint32_t frequency_millihz =
            (uint32_t)((uint64_t)bin * bin_width_millihz);

        line[0] = '\0';
        position = FftExport_AppendUint(line, sizeof(line), position, bin);
        position = FftExport_AppendText(line, sizeof(line), position, ",");
        position = FftExport_AppendUint(line, sizeof(line), position,
                                        frequency_millihz);
        position = FftExport_AppendText(line, sizeof(line), position, ",");
        position = FftExport_AppendUint(line, sizeof(line), position,
                                        FFT_GetMagnitude(bin));
        position = FftExport_AppendText(line, sizeof(line), position, ",");
        position = FftExport_AppendInt(line, sizeof(line), position,
                                       FFT_GetDbTenths(bin));
        (void)FftExport_AppendText(line, sizeof(line), position, "\r\n");

        success = FftExport_Write(&file, line, &result);
        if (success)
        {
            bins_written++;
        }
    }

    if (success)
    {
        result = f_sync(&file);
        success = (result == FR_OK);
    }

    if (file_open)
    {
        FRESULT close_result = f_close(&file);
        file_open = false;
        if (success && (close_result != FR_OK))
        {
            result = close_result;
            success = false;
        }
    }

    if (!success)
    {
        (void)f_unlink(output_name);
    }

    UART_SendString("Source File    = ");
    UART_SendString(source_name);
    UART_SendString("\r\n");
    UART_SendString("Output File    = ");
    UART_SendString(output_name);
    UART_SendString("\r\n");
    UART_SendString("Segment        = ");
    UART_SendDec(info->segment_index + 1U);
    UART_SendString(" / ");
    UART_SendDec(info->segment_count);
    UART_SendString("\r\n");
    UART_SendString("Time ms        = ");
    UART_SendDec(info->segment_time_ms);
    UART_SendString("\r\n");
    UART_SendString("FFT Size       = ");
    UART_SendDec(FFT_GetSize());
    UART_SendString("\r\n");
    UART_SendString("Bins Written   = ");
    UART_SendDec(bins_written);
    UART_SendString("\r\n");
    UART_SendString("Peak Hz        = ");
    UART_SendDec(FFT_GetPeakFrequency());
    UART_SendString("\r\n");
    UART_SendString("Peak dB x10    = ");
    if (FFT_GetPeakDbTenths() < 0)
    {
        UART_SendChar('-');
        UART_SendDec((uint32_t)(-FFT_GetPeakDbTenths()));
    }
    else
    {
        UART_SendDec((uint32_t)FFT_GetPeakDbTenths());
    }
    UART_SendString("\r\n");
    UART_SendString("Export Result  = ");
    UART_SendDec((uint32_t)result);
    UART_SendString(success ? "  PASS\r\n" : "  FAIL\r\n");
}

'''

# Insert helpers immediately before the command parser implementation.
text = once(
    text,
    "static void Console_ProcessCommand(char *command)\n",
    helpers + "static void Console_ProcessCommand(char *command)\n",
    "command parser implementation",
)

# Add command beside recstatus.
old_command = '''    else if (strcmp(command, "recstatus") == 0)
    {
        Console_RunRecStatus();
    }
'''
new_command = old_command + '''    else if (strcmp(command, "fftexport") == 0)
    {
        Console_RunFftExport();
    }
'''
text = once(text, old_command, new_command, "recstatus command block")

text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"

if text.count("{") != text.count("}"):
    fail("Brace balance failed")
if text.count("/*") != text.count("*/"):
    fail("Comment balance failed")
if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact generated")
if b"\x00" in text.encode("utf-8"):
    fail("Binary NUL generated")

for symbol in (
    MARKER,
    'strcmp(command, "fftexport")',
    "Console_RunFftExport",
    "FftExport_MakeFilename",
    "FA_CREATE_ALWAYS | FA_WRITE",
    "f_sync(&file)",
    "FFT_GetDbTenths(bin)",
    "Bin,Frequency mHz,Magnitude Counts,Level dBFS x10",
):
    if symbol not in text:
        fail("Missing generated symbol: " + symbol)

if "snprintf" in helpers or "#include <stdio.h>" in helpers:
    fail("Unexpected stdio dependency in export implementation")

MAIN_C.write_text(text, encoding="utf-8")

print("FFT CSV export patch applied successfully.")
print("UART command: fftexport")
print("Current WAV FFT segment exports to the same base name with .CSV.")
print("Original WAV is never modified; an existing matching CSV is replaced.")
print("No stdio, snprintf, malloc, or floating-point text formatting was added.")
print("Next: make clean && make -j4")
