#!/usr/bin/env python3
from pathlib import Path
import re, shutil

FILES = [Path('Core/Inc/recording_catalog.h'), Path('Core/Src/recording_catalog.c'), Path('Core/Src/ui.c'), Path('Core/Src/main.c')]
MARK = 'FFT_DISPLAY_CSV_BROWSER_COMBINED_PATCH'

def die(s): raise SystemExit(s)
def one(s,a,b,n):
    c=s.count(a)
    if c!=1: die(f'Expected exactly one {n}, found {c}')
    return s.replace(a,b,1)

def rng(s,a,b):
    x=s.rfind(a); y=s.find(b,x)
    if x<0 or y<0: die('Could not isolate '+a.strip())
    return x,y

for p in FILES:
    if not p.exists(): die('Missing '+str(p))
    if b'\0' in p.read_bytes(): die('NUL in '+str(p))

h,c,u,m=[p.read_text() for p in FILES]
if MARK in h+c+u+m: die('Combined patch already installed')
for q in ['RecordingCatalogEntry','filename_is_wav','ui_draw_file_browser_body','ui_draw_file_actions_body','ui_draw_fft_readings','FFTEXPORT_CSV_PATCH']:
    if q not in h+c+u+m: die('Missing prerequisite: '+q)
for p in FILES:
    b=p.with_name(p.name+'.before_fft_csv_browser_combined')
    if not b.exists(): shutil.copy2(p,b)

# Header
h=one(h, '''typedef struct
{
    char filename[RECORDING_FILENAME_CAPACITY];
    uint32_t file_size;
} RecordingCatalogEntry;
''', '''typedef enum
{
    RECORDING_FILE_TYPE_NONE = 0,
    RECORDING_FILE_TYPE_WAV,
    RECORDING_FILE_TYPE_CSV
} RecordingFileType;

typedef struct
{
    char filename[RECORDING_FILENAME_CAPACITY];
    uint32_t file_size;
    RecordingFileType file_type;
} RecordingCatalogEntry;
''','catalog entry')
h=one(h,'const char *RecordingCatalog_GetSelected(void);\n','''const char *RecordingCatalog_GetSelected(void);
/* FFT_DISPLAY_CSV_BROWSER_COMBINED_PATCH */
RecordingFileType RecordingCatalog_GetFileType(const char *filename);
RecordingFileType RecordingCatalog_GetSelectedType(void);
bool RecordingCatalog_SelectedIsWav(void);
bool RecordingCatalog_SelectedIsCsv(void);
''','catalog API')

# Catalog type helper replaces old WAV helper.
x=c.find('static bool filename_is_wav(const char *filename)\n'); y=c.find('FRESULT RecordingCatalog_LoadPage',x)
if x<0 or y<0: die('Could not isolate filename helper')
helper='''static bool ext3(const char *name, char a, char b, char d)
{
    size_t n; char x, y, z;
    if (name == NULL) return false;
    n = strlen(name); if (n < 4U) return false;
    x=name[n-3U]; y=name[n-2U]; z=name[n-1U];
    if (x>='a'&&x<='z') x=(char)(x-'a'+'A');
    if (y>='a'&&y<='z') y=(char)(y-'a'+'A');
    if (z>='a'&&z<='z') z=(char)(z-'a'+'A');
    return name[n-4U]=='.' && x==a && y==b && z==d;
}
RecordingFileType RecordingCatalog_GetFileType(const char *name)
{
    if (ext3(name,'W','A','V')) return RECORDING_FILE_TYPE_WAV;
    if (ext3(name,'C','S','V')) return RECORDING_FILE_TYPE_CSV;
    return RECORDING_FILE_TYPE_NONE;
}
RecordingFileType RecordingCatalog_GetSelectedType(void)
{ return RecordingCatalog_GetFileType(selected_filename); }
bool RecordingCatalog_SelectedIsWav(void)
{ return RecordingCatalog_GetSelectedType()==RECORDING_FILE_TYPE_WAV; }
bool RecordingCatalog_SelectedIsCsv(void)
{ return RecordingCatalog_GetSelectedType()==RECORDING_FILE_TYPE_CSV; }
static bool filename_is_wav(const char *name)
{ return RecordingCatalog_GetFileType(name)==RECORDING_FILE_TYPE_WAV; }
static bool filename_is_browsable(const char *name)
{ return RecordingCatalog_GetFileType(name)!=RECORDING_FILE_TYPE_NONE; }

'''
c=c[:x]+helper+c[y:]
c=one(c,'uint32_t wav_count = 0U;','uint32_t file_count = 0U;','catalog count')
c=one(c,'!filename_is_wav(information.fname)','!filename_is_browsable(information.fname)','catalog filter')
c=c.replace('wav_count','file_count')
c=one(c,'entry->file_size = (uint32_t)information.fsize;','''entry->file_size = (uint32_t)information.fsize;
            entry->file_type = RecordingCatalog_GetFileType(information.fname);''','entry type')
c=one(c,'filename_is_wav(selected_filename)','filename_is_browsable(selected_filename)','selected validation')
c=one(c,'!filename_is_wav(filename)','!filename_is_browsable(filename)','delete filter')
c=one(c,'/* UI_WAV_BROWSER_V2_PATCH */\n','/* UI_WAV_BROWSER_V2_PATCH */\n/* FFT_DISPLAY_CSV_BROWSER_COMBINED_PATCH */\n','catalog marker')

# UI marker and browser row labels.
u=one(u,'/* FFT_TIMELINE_UI_CLEANUP_PATCH */\n','/* FFT_TIMELINE_UI_CLEANUP_PATCH */\n/* FFT_DISPLAY_CSV_BROWSER_COMBINED_PATCH */\n','UI marker')
u=one(u,'''            Display_DrawString(12, y + 9, entry->filename,
                               COLOR_WHITE, background);
            ui_draw_uint(160, y + 9, entry->file_size, COLOR_YELLOW);
''','''            Display_DrawString(12, y + 9, entry->filename,
                               COLOR_WHITE, background);
            Display_DrawString(118, y + 9,
                entry->file_type == RECORDING_FILE_TYPE_CSV ? "FFT" : "WAV",
                entry->file_type == RECORDING_FILE_TYPE_CSV ? COLOR_CYAN : COLOR_GREEN,
                background);
            ui_draw_uint(160, y + 9, entry->file_size, COLOR_YELLOW);
''','browser row')

# Type-aware action body.
x,y=rng(u,'static void ui_draw_file_actions_body(void)\n','static void ui_draw_file_browser_body(void)\n')
actions='''static void ui_draw_file_actions_body(void)
{
    const char *selected=RecordingCatalog_GetSelected();
    bool csv=RecordingCatalog_SelectedIsCsv();
    FILINFO fi; FRESULT r;
    Display_FillRect(UI_GRAPH_LEFT,UI_GRAPH_TOP,UI_GRAPH_WIDTH,UI_GRAPH_HEIGHT,COLOR_BLACK);
    Display_DrawRect(UI_GRAPH_LEFT,UI_GRAPH_TOP,UI_GRAPH_WIDTH,UI_GRAPH_HEIGHT,COLOR_GRAY);
    Display_DrawString(10,44,csv?"SELECTED FFT EXPORT":"SELECTED WAV",COLOR_CYAN,COLOR_BLACK);
    Display_DrawString(10,68,selected,COLOR_GREEN,COLOR_BLACK);
    r=f_stat(selected,&fi);
    if(r==FR_OK){ Display_DrawString(10,96,"SIZE",COLOR_WHITE,COLOR_BLACK); ui_draw_uint(58,96,(uint32_t)fi.fsize,COLOR_YELLOW); Display_DrawString(140,96,"BYTES",COLOR_GRAY,COLOR_BLACK); }
    else Display_DrawString(10,96,"FILE NOT FOUND",COLOR_RED,COLOR_BLACK);
    if(csv){ Display_DrawString(10,128,"FFT CSV EXPORT",COLOR_CYAN,COLOR_BLACK); Display_DrawString(10,150,"INFO: FILE AND SIZE",COLOR_YELLOW,COLOR_BLACK); Display_DrawString(10,194,"DELETE",COLOR_RED,COLOR_BLACK); Display_DrawString(66,194,"CONFIRM",COLOR_GRAY,COLOR_BLACK); Display_DrawString(202,151,"WAV ACTIONS",COLOR_DARK_GRAY,COLOR_BLACK); Display_DrawString(202,171,"DISABLED",COLOR_DARK_GRAY,COLOR_BLACK); return; }
    Display_DrawString(10,128,"WAVE",COLOR_CYAN,COLOR_BLACK); Display_DrawString(10,150,"FFT",COLOR_GREEN,COLOR_BLACK); Display_DrawString(10,172,"INFO",COLOR_YELLOW,COLOR_BLACK); Display_DrawString(10,194,"DELETE",COLOR_RED,COLOR_BLACK); Display_DrawString(66,194,"CONFIRM",COLOR_GRAY,COLOR_BLACK);
    Display_FillRect(UI_RENAME_BUTTON_X,UI_RENAME_BUTTON_Y,UI_RENAME_BUTTON_WIDTH,UI_RENAME_BUTTON_HEIGHT,COLOR_MAGENTA); Display_DrawRect(UI_RENAME_BUTTON_X,UI_RENAME_BUTTON_Y,UI_RENAME_BUTTON_WIDTH,UI_RENAME_BUTTON_HEIGHT,COLOR_WHITE); Display_DrawString(220,151,"RENAME",COLOR_BLACK,COLOR_MAGENTA); Display_DrawString(202,171,"EDIT WAV NAME",COLOR_BLACK,COLOR_MAGENTA);
}

'''
u=u[:x]+actions+u[y:]

# dB tenths formatter prototype and function.
u=one(u,'''static void ui_format_time_seconds(uint32_t time_ms,
                                   char *buffer,
                                   uint32_t buffer_size);
''','''static void ui_format_time_seconds(uint32_t time_ms,
                                   char *buffer,
                                   uint32_t buffer_size);
static void ui_format_dbfs_tenths(int16_t value, char *buffer, uint32_t size);
''','dB formatter prototype')
fmt='''static void ui_format_dbfs_tenths(int16_t value, char *buffer, uint32_t size)
{
    uint32_t p=0U, mag;
    if(buffer==NULL||size==0U) return;
    buffer[0]='\0';
    if(value<0){ p=ui_append_text(buffer,size,p,"-"); mag=(uint32_t)(-(value+1))+1U; }
    else mag=(uint32_t)value;
    p=ui_append_uint_text(buffer,size,p,mag/10U,1U);
    p=ui_append_text(buffer,size,p,".");
    p=ui_append_uint_text(buffer,size,p,mag%10U,1U);
    (void)ui_append_text(buffer,size,p," dBFS");
}

'''
u=one(u,'static void ui_draw_fft_readings(void)\n',fmt+'static void ui_draw_fft_readings(void)\n','dB formatter')
x,y=rng(u,'static void ui_draw_fft_readings(void)\n','static bool ui_fft_timeline_contains')
readings='''static void ui_draw_fft_readings(void)
{
    const WavFftViewerInfo *info=WavFftViewer_GetInfo();
    char freq[16],time[16],level[20];
    if(info==NULL||!info->active) return;
    Display_FillRect(34,34,112,18,COLOR_BLACK); Display_DrawString(36,36,"SEG",COLOR_WHITE,COLOR_BLACK); ui_draw_uint(62,36,info->segment_index+1U,COLOR_YELLOW); Display_DrawString(92,36,"/",COLOR_GRAY,COLOR_BLACK); ui_draw_uint(102,36,info->segment_count,COLOR_YELLOW);
    ui_format_time_seconds(info->segment_time_ms,time,sizeof(time)); Display_FillRect(148,34,170,18,COLOR_BLACK); Display_DrawString(150,36,"TIME",COLOR_WHITE,COLOR_BLACK); Display_DrawString(190,36,time,COLOR_CYAN,COLOR_BLACK);
    ui_format_peak_frequency(FFT_GetPeakFrequency(),freq,sizeof(freq)); ui_format_dbfs_tenths(FFT_GetPeakDbTenths(),level,sizeof(level)); Display_FillRect(34,54,284,18,COLOR_BLACK); Display_DrawString(36,56,"PEAK",COLOR_WHITE,COLOR_BLACK); Display_DrawString(74,56,freq,COLOR_GREEN,COLOR_BLACK); Display_DrawString(170,56,"LEVEL",COLOR_WHITE,COLOR_BLACK); Display_DrawString(218,56,level,COLOR_YELLOW,COLOR_BLACK);
}

'''
u=u[:x]+readings+u[y:]
u=one(u,'''    Display_DrawString(3,
                       UI_GRAPH_TOP + 2,
                       "DBFS",
                       COLOR_CYAN,
                       COLOR_BLACK);
''','', 'DBFS label')

# Recorded FFT bottom status.
s=u.rfind('static void ui_draw_status(void)\n'); x=u.find('    if (ui.mode == UI_MODE_RECORDED_FFT)\n',s); y=u.find('    if (ui.mode == UI_MODE_WAVEFORM)\n',x)
if min(s,x,y)<0: die('Could not isolate FFT status')
u=u[:x]+'''    if (ui.mode == UI_MODE_RECORDED_FFT)
    {
        Display_FillRect(0,UI_STATUS_TOP,DISPLAY_WIDTH,UI_STATUS_HEIGHT,COLOR_BLACK);
        Display_DrawRect(0,UI_STATUS_TOP,DISPLAY_WIDTH,UI_STATUS_HEIGHT,COLOR_GRAY);
        Display_DrawString(70,UI_STATUS_TOP+8,"TAP GRAPH FOR TIMELINE",COLOR_CYAN,COLOR_BLACK);
        return;
    }

'''+u[y:]

# Main guards.
m=one(m,'/* FFT_EVENT_SCAN_MARKERS_PATCH */\n','/* FFT_EVENT_SCAN_MARKERS_PATCH */\n/* FFT_DISPLAY_CSV_BROWSER_COMBINED_PATCH */\n','main marker')
m=one(m,'''        case UI_ACTION_VIEW_WAVEFORM:
            if (Capture_IsRecorderActive())
''','''        case UI_ACTION_VIEW_WAVEFORM:
            if (!RecordingCatalog_SelectedIsWav()) { UART_SendString("WAVE blocked: select a WAV file\r\n"); break; }
            if (Capture_IsRecorderActive())
''','wave guard')
m=one(m,'''        case UI_ACTION_VIEW_SPECTRUM:
            if (Capture_IsRecorderActive())
''','''        case UI_ACTION_VIEW_SPECTRUM:
            if (!RecordingCatalog_SelectedIsWav()) { UART_SendString("FFT blocked: select a WAV file\r\n"); break; }
            if (Capture_IsRecorderActive())
''','FFT guard')
m=one(m,'''        case UI_ACTION_FILE_INFO:
        {
            UI_WavInfo info;

            result = UI_LoadSelectedWavInfo(&info);
''','''        case UI_ACTION_FILE_INFO:
        {
            UI_WavInfo info;
            if (RecordingCatalog_SelectedIsCsv()) { UART_SendString("UI FFT CSV info: "); UART_SendString(RecordingCatalog_GetSelected()); UART_SendString("\r\n"); UI_ShowFileActions(); break; }
            result = UI_LoadSelectedWavInfo(&info);
''','CSV info')
m=one(m,'''        case UI_ACTION_FILE_RENAME_OPEN:
            if (Capture_IsRecorderActive())
''','''        case UI_ACTION_FILE_RENAME_OPEN:
            if (!RecordingCatalog_SelectedIsWav()) { UART_SendString("Rename blocked: select a WAV file\r\n"); break; }
            if (Capture_IsRecorderActive())
''','rename guard')
m=m.replace('Select a valid WAV before OPEN','Select a valid file before OPEN').replace('Select a valid WAV before delete','Select a valid file before delete').replace('UI selected WAV: ','UI selected file: ').replace('UI file browser has no WAV files','UI file browser has no WAV or CSV files')

outs=[(FILES[0],h),(FILES[1],c),(FILES[2],u),(FILES[3],m)]
for p,s in outs:
    s='\n'.join(x.rstrip() for x in s.splitlines())+'\n'
    if s.count('{')!=s.count('}'): die('Brace mismatch in '+str(p))
    if re.search(r'&(lt|gt|amp);|<br',s): die('HTML artifact in '+str(p))
    p.write_text(s)

print('Combined FFT display and WAV/CSV browser patch applied successfully.')
print('Browser lists WAV and CSV files with WAV/FFT labels.')
print('CSV delete is allowed; WAV-only actions are blocked.')
print('FFT readings are shown once with LEVEL in tenths dBFS.')
print('Bottom status: TAP GRAPH FOR TIMELINE.')
print('Next: make clean && make -j4')
