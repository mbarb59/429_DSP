#!/usr/bin/env python3
"""Add a one-second MIC RMS and clip-status update to lightweight REC progress."""

from pathlib import Path
import re
import shutil

UI_C = Path("Core/Src/ui.c")
MARKER = "UI_RMS_1HZ_UPDATE_PATCH"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


if not UI_C.exists():
    fail(f"Missing required file: {UI_C}")

raw = UI_C.read_bytes()
if b"\x00" in raw:
    fail("Binary NUL found in Core/Src/ui.c")

text = raw.decode("utf-8")

if MARKER in text:
    fail("One-second RMS update is already installed")

if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact found in Core/Src/ui.c")

for prerequisite in (
    "UI_LIGHTWEIGHT_PROGRESS_V2_PATCH",
    "UI_LIGHTWEIGHT_PROGRESS_RESET_FIX",
    "UI_PROGRESS_FIELD_OVERLAP_FIX",
    "ui_draw_recording_progress_dynamic(bool force)",
    'Display_DrawString(188, 62, "MIC RMS"',
):
    if prerequisite not in text:
        fail("Missing prerequisite: " + prerequisite)

backup = UI_C.with_name(UI_C.name + ".before_rms_1hz_update")
if not backup.exists():
    shutil.copy2(UI_C, backup)

# Add dedicated geometry without touching progress fields.
geometry_anchor = "#define UI_PROGRESS_BAR_INNER_H          8U\n"
geometry = geometry_anchor + """#define UI_MIC_RMS_VALUE_X              248
#define UI_MIC_RMS_VALUE_Y               62
#define UI_MIC_RMS_VALUE_W               40U
#define UI_MIC_RMS_VALUE_H               16U
#define UI_MIC_CLIP_VALUE_X              292
#define UI_MIC_CLIP_VALUE_Y               62
#define UI_MIC_CLIP_VALUE_W               24U
#define UI_MIC_CLIP_VALUE_H               16U
"""
text = once(text, geometry_anchor, geometry, "progress geometry tail")

# Add display-state fields.
text = once(
    text,
    "    uint32_t last_remaining_seconds;\n",
    """    uint32_t last_remaining_seconds;
    uint32_t last_displayed_rms;
    bool last_displayed_clipping;
""",
    "progress state tail",
)

# Initialize state.
text = once(
    text,
    """    ui.last_progress_percent = 0U;
    ui.last_remaining_seconds = 0U;
""",
    """    ui.last_progress_percent = 0U;
    ui.last_remaining_seconds = 0U;
    ui.last_displayed_rms = UINT32_MAX;
    ui.last_displayed_clipping = false;
""",
    "progress initialization",
)

# Insert the RMS update at the end of the existing once-per-second dynamic
# function. It clears only the numeric and status rectangles.
dynamic_tail = """        ui.last_progress_percent = percent;
    }
}

static void ui_draw_recording_progress_static(void)
"""
rms_update = """        ui.last_progress_percent = percent;
    }

    /* UI_RMS_1HZ_UPDATE_PATCH
     * This function is gated by UI_PROGRESS_PERIOD_MS, so MIC RMS and the
     * clip indicator update at the same one-second rate as progress.
     */
    if (force ||
        (ui.recorder_status.rms_counts != ui.last_displayed_rms))
    {
        Display_FillRect(UI_MIC_RMS_VALUE_X,
                         UI_MIC_RMS_VALUE_Y,
                         UI_MIC_RMS_VALUE_W,
                         UI_MIC_RMS_VALUE_H,
                         COLOR_BLACK);
        ui_draw_uint(UI_MIC_RMS_VALUE_X,
                     UI_MIC_RMS_VALUE_Y,
                     ui.recorder_status.rms_counts,
                     COLOR_YELLOW);
        ui.last_displayed_rms = ui.recorder_status.rms_counts;
    }

    if (force ||
        (ui.recorder_status.clipping != ui.last_displayed_clipping))
    {
        Display_FillRect(UI_MIC_CLIP_VALUE_X,
                         UI_MIC_CLIP_VALUE_Y,
                         UI_MIC_CLIP_VALUE_W,
                         UI_MIC_CLIP_VALUE_H,
                         COLOR_BLACK);
        Display_DrawString(UI_MIC_CLIP_VALUE_X,
                           UI_MIC_CLIP_VALUE_Y,
                           ui.recorder_status.clipping ? "!" : "OK",
                           ui.recorder_status.clipping ? COLOR_RED : COLOR_GREEN,
                           COLOR_BLACK);
        ui.last_displayed_clipping = ui.recorder_status.clipping;
    }
}

static void ui_draw_recording_progress_static(void)
"""
text = once(text, dynamic_tail, rms_update, "dynamic progress function tail")

# Reset RMS display state before each capture, allowing the first one-second
# update to draw the current value cleanly.
reset_anchor = """    ui.last_progress_percent = 0U;
    ui.last_remaining_seconds = target;
    ui.last_progress_draw_ms = HAL_GetTick();
    ui.recorder_progress_dirty = false;
"""
reset_replacement = """    ui.last_progress_percent = 0U;
    ui.last_remaining_seconds = target;
    ui.last_displayed_rms = UINT32_MAX;
    ui.last_displayed_clipping = !ui.recorder_status.clipping;
    ui.last_progress_draw_ms = HAL_GetTick();
    ui.recorder_progress_dirty = false;
"""
text = once(text, reset_anchor, reset_replacement, "progress reset state")

# Add a feature marker near the progress marker.
text = once(
    text,
    "/* UI_LIGHTWEIGHT_PROGRESS_V2_PATCH */\n",
    """/* UI_LIGHTWEIGHT_PROGRESS_V2_PATCH */
/* UI_RMS_1HZ_UPDATE_PATCH */
""",
    "lightweight progress marker",
)

text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"

if text.count("{") != text.count("}"):
    fail("Brace balance failed")
if text.count("/*") != text.count("*/"):
    fail("Comment balance failed")
if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact generated")
if b"\x00" in text.encode("utf-8"):
    fail("Binary NUL generated")

for symbol in (
    MARKER,
    "UI_MIC_RMS_VALUE_X",
    "last_displayed_rms",
    "last_displayed_clipping",
    "ui.recorder_status.rms_counts",
):
    if symbol not in text:
        fail("Missing generated symbol: " + symbol)

# Ensure no full-screen draw or new update period was introduced.
if text.count("#define UI_PROGRESS_PERIOD_MS") != 1:
    fail("Progress update period changed or duplicated")

UI_C.write_text(text, encoding="utf-8")

print("One-second MIC RMS update patch applied successfully.")
print("Modified: Core/Src/ui.c")
print("RMS and clip status update with the existing one-second progress cycle.")
print("Only two small rectangles are cleared and redrawn.")
print("No DMA, queue, FatFs, or full-screen redraw logic was changed.")
print("Next: make clean && make -j4")
