#!/usr/bin/env python3
"""Add a clear visual separator above the recorded FFT timeline."""

from pathlib import Path
import re
import shutil

UI_C = Path("Core/Src/ui.c")
MARKER = "FFT_TIMELINE_SEPARATOR_PATCH"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


if not UI_C.exists():
    fail(f"Missing required file: {UI_C}")

raw = UI_C.read_bytes()
if b"\x00" in raw:
    fail("Binary NUL found in Core/Src/ui.c")

text = raw.decode("utf-8")

if MARKER in text:
    fail("FFT timeline separator is already installed")

if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact found in Core/Src/ui.c")

for prerequisite in (
    "RECORDED_FFT_TIMELINE_SCRUBBER_PATCH",
    "UI_FFT_TIMELINE_Y",
    "static void ui_draw_fft_timeline(void)",
    "UI_FFT_TIMELINE_LINE_Y",
):
    if prerequisite not in text:
        fail("Missing prerequisite: " + prerequisite)

backup = UI_C.with_name(UI_C.name + ".before_fft_timeline_separator")
if not backup.exists():
    shutil.copy2(UI_C, backup)

text = once(
    text,
    "#define UI_FFT_TIMELINE_TOUCH_MARGIN       4U\n",
    """#define UI_FFT_TIMELINE_TOUCH_MARGIN       4U

/* FFT_TIMELINE_SEPARATOR_PATCH */
#define UI_FFT_TIMELINE_SEPARATOR_Y \
    (UI_FFT_TIMELINE_Y - 2)
""",
    "timeline touch-margin definition",
)

old_draw = '''    Display_FillRect(UI_FFT_TIMELINE_X - 2,
                     UI_FFT_TIMELINE_Y,
                     UI_FFT_TIMELINE_WIDTH + 4U,
                     UI_FFT_TIMELINE_HEIGHT,
                     COLOR_BLACK);
    Display_DrawLine(UI_FFT_TIMELINE_X,
                     UI_FFT_TIMELINE_LINE_Y,
'''

new_draw = '''    Display_FillRect(UI_FFT_TIMELINE_X - 2,
                     UI_FFT_TIMELINE_Y,
                     UI_FFT_TIMELINE_WIDTH + 4U,
                     UI_FFT_TIMELINE_HEIGHT,
                     COLOR_BLACK);

    /* Separate the FFT plot from the timeline without changing touch logic. */
    Display_DrawLine(UI_GRAPH_LEFT,
                     UI_FFT_TIMELINE_SEPARATOR_Y,
                     UI_GRAPH_RIGHT,
                     UI_FFT_TIMELINE_SEPARATOR_Y,
                     COLOR_CYAN);
    Display_DrawLine(UI_GRAPH_LEFT,
                     UI_FFT_TIMELINE_SEPARATOR_Y + 1,
                     UI_GRAPH_RIGHT,
                     UI_FFT_TIMELINE_SEPARATOR_Y + 1,
                     COLOR_DARK_GRAY);

    Display_DrawLine(UI_FFT_TIMELINE_X,
                     UI_FFT_TIMELINE_LINE_Y,
'''

text = once(text, old_draw, new_draw, "timeline background drawing block")

text = once(
    text,
    "/* RECORDED_FFT_TIMELINE_SCRUBBER_PATCH */\n",
    """/* RECORDED_FFT_TIMELINE_SCRUBBER_PATCH */
/* FFT_TIMELINE_SEPARATOR_PATCH */
""",
    "timeline feature marker",
)

text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"

if text.count("{") != text.count("}"):
    fail("Brace balance failed")
if text.count("/*") != text.count("*/"):
    fail("Comment balance failed")
if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact generated")
if b"\x00" in text.encode("utf-8"):
    fail("Binary NUL generated")

for symbol in (
    MARKER,
    "UI_FFT_TIMELINE_SEPARATOR_Y",
    "COLOR_CYAN",
    "COLOR_DARK_GRAY",
):
    if symbol not in text:
        fail("Missing generated symbol: " + symbol)

UI_C.write_text(text, encoding="utf-8")

print("FFT timeline separator patch applied successfully.")
print("Modified: Core/Src/ui.c")
print("Added a cyan line with a dark-gray lower edge above the timeline.")
print("Timeline touch mapping and WAV segment loading were unchanged.")
print("Next: make clean && make -j4")
