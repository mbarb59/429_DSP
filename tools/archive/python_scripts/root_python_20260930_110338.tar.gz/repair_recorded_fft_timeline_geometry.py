#!/usr/bin/env python3
"""Reserve a dedicated plot area above the recorded FFT timeline.

This repair compresses only the recorded-WAV dBFS graph into the area above
its separator. The live analyzer keeps the original full-height graph.
"""

from pathlib import Path
import re
import shutil

UI_C = Path("Core/Src/ui.c")
MARKER = "RECORDED_FFT_TIMELINE_GEOMETRY_FIX"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


if not UI_C.exists():
    fail(f"Missing required file: {UI_C}")

raw = UI_C.read_bytes()
if b"\x00" in raw:
    fail("Binary NUL found in Core/Src/ui.c")

text = raw.decode("utf-8")

if MARKER in text:
    fail("Recorded FFT timeline geometry repair is already installed")

if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact found in Core/Src/ui.c")

for prerequisite in (
    "RECORDED_FFT_DB_DISPLAY_V1_PATCH",
    "RECORDED_FFT_TIMELINE_SCRUBBER_PATCH",
    "FFT_TIMELINE_SEPARATOR_PATCH",
    "UI_FFT_TIMELINE_SEPARATOR_Y",
    "static int32_t ui_db_tenths_to_y(int16_t db_tenths)",
    "static void ui_draw_db_grid(void)",
):
    if prerequisite not in text:
        fail("Missing prerequisite: " + prerequisite)

backup = UI_C.with_name(UI_C.name + ".before_recorded_fft_timeline_geometry")
if not backup.exists():
    shutil.copy2(UI_C, backup)

# Reserve the row above the separator as the final recorded-FFT plot row.
# The active project uses a one-line separator definition.
geometry_anchor = "#define UI_FFT_TIMELINE_SEPARATOR_Y     (UI_FFT_TIMELINE_Y - 2)\n"
geometry_replacement = geometry_anchor + '''
/* RECORDED_FFT_TIMELINE_GEOMETRY_FIX */
#define UI_RECORDED_FFT_GRAPH_BOTTOM \
    (UI_FFT_TIMELINE_SEPARATOR_Y - 1)
#define UI_RECORDED_FFT_GRAPH_HEIGHT \
    (UI_RECORDED_FFT_GRAPH_BOTTOM - UI_GRAPH_TOP + 1)
'''
text = once(
    text,
    geometry_anchor,
    geometry_replacement,
    "one-line timeline separator geometry",
)

# Map 0 to -90 dBFS into only the dedicated recorded-FFT plot height.
old_mapping = '''static int32_t ui_db_tenths_to_y(int16_t db_tenths)
{
    int32_t value = db_tenths;
    uint32_t usable_height = (uint32_t)UI_GRAPH_HEIGHT - 2U;

    if (value > 0)
    {
        value = 0;
    }
    else if (value < -900)
    {
        value = -900;
    }

    return UI_GRAPH_TOP + 1 +
           (int32_t)(((-value) * usable_height) / 900);
}
'''

new_mapping = '''static int32_t ui_db_tenths_to_y(int16_t db_tenths)
{
    int32_t value = db_tenths;
    uint32_t usable_height =
        (uint32_t)UI_RECORDED_FFT_GRAPH_HEIGHT - 2U;

    if (value > 0)
    {
        value = 0;
    }
    else if (value < -900)
    {
        value = -900;
    }

    return UI_GRAPH_TOP + 1 +
           (int32_t)(((-value) * usable_height) / 900);
}
'''
text = once(text, old_mapping, new_mapping, "recorded FFT dB mapping")

# Give the recorded-FFT grid its own shorter border and vertical lines.
old_border = '''    Display_DrawRect(UI_GRAPH_LEFT,
                     UI_GRAPH_TOP,
                     UI_GRAPH_WIDTH,
                     UI_GRAPH_HEIGHT,
                     COLOR_GRAY);
'''
new_border = '''    Display_DrawRect(UI_GRAPH_LEFT,
                     UI_GRAPH_TOP,
                     UI_GRAPH_WIDTH,
                     UI_RECORDED_FFT_GRAPH_HEIGHT,
                     COLOR_GRAY);
'''

# Restrict the replacement to ui_draw_db_grid(), because the normal analyzer
# deliberately retains the original full-height rectangle.
db_start = text.find("static void ui_draw_db_grid(void)\n")
db_end = text.find("static void ui_draw_db_spectrum_trace(void)\n", db_start)
if db_start < 0 or db_end < 0:
    fail("Could not isolate ui_draw_db_grid")

db_function = text[db_start:db_end]
db_function = once(
    db_function,
    old_border,
    new_border,
    "recorded FFT dB grid border",
)
db_function = once(
    db_function,
    '''        Display_DrawLine(x,
                         UI_GRAPH_TOP,
                         x,
                         UI_GRAPH_BOTTOM,
                         COLOR_DARK_GRAY);
''',
    '''        Display_DrawLine(x,
                         UI_GRAPH_TOP,
                         x,
                         UI_RECORDED_FFT_GRAPH_BOTTOM,
                         COLOR_DARK_GRAY);
''',
    "recorded FFT vertical grid line",
)
text = text[:db_start] + db_function + text[db_end:]

# Clamp the dB peak marker to the shorter plot area as a defensive guard.
peak_start = text.find("static void ui_draw_db_peak_marker(void)\n")
peak_end = text.find("static void ui_draw_grid(void)\n", peak_start)
if peak_start < 0 or peak_end < 0:
    fail("Could not isolate ui_draw_db_peak_marker")

peak_function = text[peak_start:peak_end]
peak_function = once(
    peak_function,
    '''    peak_y = ui_db_tenths_to_y(
        FFT_GetPeakDbTenths());
    marker_top = peak_y - 10;
''',
    '''    peak_y = ui_db_tenths_to_y(
        FFT_GetPeakDbTenths());

    if (peak_y > UI_RECORDED_FFT_GRAPH_BOTTOM)
    {
        peak_y = UI_RECORDED_FFT_GRAPH_BOTTOM;
    }

    marker_top = peak_y - 10;
''',
    "recorded FFT peak Y calculation",
)
text = text[:peak_start] + peak_function + text[peak_end:]

# Add a source marker beside the separator marker.
text = once(
    text,
    "/* FFT_TIMELINE_SEPARATOR_PATCH */\n",
    '''/* FFT_TIMELINE_SEPARATOR_PATCH */
/* RECORDED_FFT_TIMELINE_GEOMETRY_FIX */
''',
    "timeline separator feature marker",
)

text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"

if text.count("{") != text.count("}"):
    fail("Brace balance failed")
if text.count("/*") != text.count("*/"):
    fail("Comment balance failed")
if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact generated")
if b"\x00" in text.encode("utf-8"):
    fail("Binary NUL generated")

for symbol in (
    MARKER,
    "UI_RECORDED_FFT_GRAPH_BOTTOM",
    "UI_RECORDED_FFT_GRAPH_HEIGHT",
    "UI_RECORDED_FFT_GRAPH_HEIGHT - 2U",
    "UI_RECORDED_FFT_GRAPH_BOTTOM,",
):
    if symbol not in text:
        fail("Missing generated symbol: " + symbol)

# Ensure the live analyzer's full-height mapping and grid still exist.
if "uint32_t usable_height;" not in text:
    fail("Live analyzer linear magnitude mapping appears to be missing")
if text.count("UI_GRAPH_HEIGHT") < 3:
    fail("Live analyzer full-height geometry appears to have been removed")

UI_C.write_text(text, encoding="utf-8")

print("Recorded FFT timeline geometry repair applied successfully.")
print("Modified: Core/Src/ui.c")
print("Recorded dBFS plot now ends above the timeline separator.")
print("The full 0 to -90 dBFS range is compressed into the visible plot area.")
print("Live analyzer geometry and timeline touch behavior were unchanged.")
print("Next: make clean && make -j4")
