#!/usr/bin/env python3
"""Reset lightweight REC progress before each timed recording starts."""

from pathlib import Path
import re
import shutil

UI_H = Path("Core/Inc/ui.h")
UI_C = Path("Core/Src/ui.c")
MAIN = Path("Core/Src/main.c")
MARKER = "UI_LIGHTWEIGHT_PROGRESS_RESET_FIX"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


for path in (UI_H, UI_C, MAIN):
    if not path.exists():
        fail("Missing required file: " + str(path))
    if b"\x00" in path.read_bytes():
        fail("Binary NUL found in " + str(path))

h = UI_H.read_text(encoding="utf-8")
u = UI_C.read_text(encoding="utf-8")
m = MAIN.read_text(encoding="utf-8")

for path, text in ((UI_H, h), (UI_C, u), (MAIN, m)):
    if MARKER in text:
        fail("Progress reset fix already installed in " + str(path))
    if re.search(r"&(lt|gt|amp);|<br", text):
        fail("HTML artifact found in " + str(path))

for symbol in (
    "UI_LIGHTWEIGHT_PROGRESS_V2_PATCH",
    "UI_ProcessRecorderDisplay",
    "ui_draw_recording_progress_static",
    "UI_PROGRESS_BAR_INNER_W",
    "Capture_StartRecorder(duration_seconds)",
):
    if symbol not in h + u + m:
        fail("Missing prerequisite: " + symbol)

for path in (UI_H, UI_C, MAIN):
    backup = path.with_name(path.name + ".before_progress_reset_fix")
    if not backup.exists():
        shutil.copy2(path, backup)

h = once(
    h,
    "void UI_ProcessRecorderDisplay(void);\n",
    """void UI_ProcessRecorderDisplay(void);
void UI_ResetRecordingProgress(void);
""",
    "progress display prototype",
)

reset_function = r'''void UI_ResetRecordingProgress(void)
{
    uint32_t target = ui_recording_target_seconds();

    /* UI_LIGHTWEIGHT_PROGRESS_RESET_FIX
     * Reset only the tiny dynamic regions before DMA capture starts.
     */
    Display_FillRect(UI_PROGRESS_REMAIN_X,
                     UI_PROGRESS_REMAIN_Y,
                     UI_PROGRESS_REMAIN_W,
                     UI_PROGRESS_REMAIN_H,
                     COLOR_BLACK);
    ui_draw_uint(UI_PROGRESS_REMAIN_X,
                 UI_PROGRESS_REMAIN_Y,
                 target,
                 COLOR_YELLOW);

    Display_FillRect(UI_PROGRESS_PERCENT_X,
                     UI_PROGRESS_PERCENT_Y,
                     UI_PROGRESS_PERCENT_W,
                     UI_PROGRESS_PERCENT_H,
                     COLOR_BLACK);
    ui_draw_uint(UI_PROGRESS_PERCENT_X,
                 UI_PROGRESS_PERCENT_Y,
                 0U,
                 COLOR_GREEN);

    Display_FillRect(UI_PROGRESS_BAR_INNER_X,
                     UI_PROGRESS_BAR_INNER_Y,
                     UI_PROGRESS_BAR_INNER_W,
                     UI_PROGRESS_BAR_INNER_H,
                     COLOR_DARK_GRAY);

    ui.last_progress_percent = 0U;
    ui.last_remaining_seconds = target;
    ui.last_progress_draw_ms = HAL_GetTick();
    ui.recorder_progress_dirty = false;
}

'''

u = once(
    u,
    "void UI_ProcessRecorderDisplay(void)\n",
    reset_function + "void UI_ProcessRecorderDisplay(void)\n",
    "progress display implementation",
)

m = once(
    m,
    "/* UI_LIGHTWEIGHT_PROGRESS_V2_PATCH */\n",
    """/* UI_LIGHTWEIGHT_PROGRESS_V2_PATCH */
/* UI_LIGHTWEIGHT_PROGRESS_RESET_FIX */
""",
    "lightweight progress marker",
)

case_start = m.find("        case UI_ACTION_RECORD_DURATION:\n")
case_end = m.find("        case UI_ACTION_RECORD_5:\n", case_start)
if case_start < 0 or case_end < 0:
    fail("Could not isolate UI_ACTION_RECORD_DURATION")

case = m[case_start:case_end]
case = once(
    case,
    """            if (!Capture_StartRecorder(duration_seconds))
""",
    """            UI_ResetRecordingProgress();

            if (!Capture_StartRecorder(duration_seconds))
""",
    "timed recorder DMA start",
)
m = m[:case_start] + case + m[case_end:]

outputs = []
for path, text in ((UI_H, h), (UI_C, u), (MAIN, m)):
    text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"
    if text.count("{") != text.count("}"):
        fail("Brace mismatch in " + str(path))
    if text.count("/*") != text.count("*/"):
        fail("Comment mismatch in " + str(path))
    if b"\x00" in text.encode("utf-8"):
        fail("Binary NUL generated in " + str(path))
    outputs.append((path, text))

joined = "\n".join(text for _, text in outputs)
for symbol in (
    MARKER,
    "UI_ResetRecordingProgress",
    "ui.last_progress_percent = 0U",
    "UI_PROGRESS_BAR_INNER_W",
):
    if symbol not in joined:
        fail("Missing generated symbol: " + symbol)

if m.count("UI_ResetRecordingProgress();") != 1:
    fail("Progress-reset call missing or duplicated")

for path, text in outputs:
    path.write_text(text, encoding="utf-8")

print("Lightweight REC progress reset fix applied successfully.")
print("Remaining seconds, percentage, and bar now reset before each capture.")
print("No full-screen redraw was added during recording.")
print("Next: make clean && make -j4")
