#!/usr/bin/env python3
"""Add a fixed 0 to -90 dBFS scale to recorded-WAV FFT mode only.

Modified files:
  Core/Inc/fft.h
  Core/Src/fft.c
  Core/Src/ui.c

The live analyzer keeps its existing linear-magnitude display.
"""

from pathlib import Path
import re
import shutil

FFT_H = Path("Core/Inc/fft.h")
FFT_C = Path("Core/Src/fft.c")
UI_C = Path("Core/Src/ui.c")
MARKER = "RECORDED_FFT_DB_DISPLAY_V1_PATCH"


def fail(message):
    raise SystemExit(message)


def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


def backup(path):
    target = path.with_name(path.name + ".before_recorded_fft_db_v1")
    if not target.exists():
        shutil.copy2(path, target)


for path in (FFT_H, FFT_C, UI_C):
    if not path.exists():
        fail("Missing required file: " + str(path))
    if b"\x00" in path.read_bytes():
        fail("Binary NUL found in " + str(path))

fft_h = FFT_H.read_text(encoding="utf-8")
fft_c = FFT_C.read_text(encoding="utf-8")
ui_c = UI_C.read_text(encoding="utf-8")

for path, text in ((FFT_H, fft_h), (FFT_C, fft_c), (UI_C, ui_c)):
    if MARKER in text:
        fail("Recorded FFT dB display is already installed in " + str(path))
    if re.search(r"&(lt|gt|amp);|<br", text):
        fail("HTML artifact found in " + str(path))

combined = fft_h + fft_c + ui_c
for symbol in (
    "FFT_GetMagnitude",
    "static void calculate_magnitudes(void)",
    "UI_MODE_RECORDED_FFT",
    "static void ui_draw_spectrum_trace(void)",
    "static void ui_draw_peak_marker(void)",
):
    if symbol not in combined:
        fail("Missing prerequisite: " + symbol)

for path in (FFT_H, FFT_C, UI_C):
    backup(path)

# -------------------------------------------------------------------------
# Core/Inc/fft.h
# -------------------------------------------------------------------------
fft_h = replace_once(
    fft_h,
    "uint32_t FFT_GetMagnitude(uint32_t bin);\n",
    """uint32_t FFT_GetMagnitude(uint32_t bin);

/* RECORDED_FFT_DB_DISPLAY_V1_PATCH */
int16_t FFT_GetDbTenths(uint32_t bin);
int16_t FFT_GetPeakDbTenths(void);
""",
    "FFT magnitude accessor",
)

# -------------------------------------------------------------------------
# Core/Src/fft.c
# -------------------------------------------------------------------------
fft_c = replace_once(
    fft_c,
    "#define FFT_DEFAULT_RATE_HZ    48000U\n",
    """#define FFT_DEFAULT_RATE_HZ    48000U

/* RECORDED_FFT_DB_DISPLAY_V1_PATCH */
#define FFT_DB_REFERENCE_COUNTS  2048.0f
#define FFT_DB_FLOOR_TENTHS      (-900)
""",
    "FFT default-rate definition",
)

fft_c = replace_once(
    fft_c,
    "static float magnitudes[FFT_BIN_COUNT_MAX];\n",
    """static float magnitudes[FFT_BIN_COUNT_MAX];
static int16_t db_tenths[FFT_BIN_COUNT_MAX];
""",
    "FFT magnitude array",
)

fft_c = replace_once(
    fft_c,
    "static uint32_t peak_frequency_hz;\n",
    """static uint32_t peak_frequency_hz;
static int16_t peak_db_tenths = FFT_DB_FLOOR_TENTHS;
""",
    "FFT peak-frequency state",
)

conversion_function = '''static int16_t magnitude_to_db_tenths(float magnitude)
{
    float db;

    if (magnitude <= 0.0f)
    {
        return FFT_DB_FLOOR_TENTHS;
    }

    db = 20.0f * log10f(magnitude / FFT_DB_REFERENCE_COUNTS);

    if (db > 0.0f)
    {
        db = 0.0f;
    }
    else if (db < -90.0f)
    {
        db = -90.0f;
    }

    return (int16_t)((db * 10.0f) +
                     ((db >= 0.0f) ? 0.5f : -0.5f));
}

'''

fft_c = replace_once(
    fft_c,
    "static void calculate_magnitudes(void)\n",
    conversion_function + "static void calculate_magnitudes(void)\n",
    "calculate_magnitudes definition",
)

fft_c = replace_once(
    fft_c,
    """        magnitude *= (4.0f / (float)active_fft_size);
        magnitudes[bin] = magnitude;

        /* Ignore DC when locating the spectral peak. */
""",
    """        magnitude *= (4.0f / (float)active_fft_size);
        magnitudes[bin] = magnitude;
        db_tenths[bin] = magnitude_to_db_tenths(magnitude);

        /* Ignore DC when locating the spectral peak. */
""",
    "magnitude storage block",
)

fft_c = replace_once(
    fft_c,
    """    peak_frequency_hz =
        (uint32_t)(((uint64_t)peak_bin * fft_sample_rate_hz +
                    (active_fft_size / 2U)) /
                   active_fft_size);
}
""",
    """    peak_frequency_hz =
        (uint32_t)(((uint64_t)peak_bin * fft_sample_rate_hz +
                    (active_fft_size / 2U)) /
                   active_fft_size);
    peak_db_tenths = db_tenths[peak_bin];
}
""",
    "peak-frequency calculation",
)

fft_c = replace_once(
    fft_c,
    """    peak_bin = 0U;
    peak_frequency_hz = 0U;
}
""",
    """    peak_bin = 0U;
    peak_frequency_hz = 0U;
    peak_db_tenths = FFT_DB_FLOOR_TENTHS;
}
""",
    "FFT invalidate state",
)

fft_accessors = '''int16_t FFT_GetDbTenths(uint32_t bin)
{
    if (bin >= active_bin_count)
    {
        return FFT_DB_FLOOR_TENTHS;
    }

    return db_tenths[bin];
}

int16_t FFT_GetPeakDbTenths(void)
{
    return peak_db_tenths;
}

'''

fft_c = replace_once(
    fft_c,
    "int32_t FFT_GetCenteredSample(uint32_t index)\n",
    fft_accessors + "int32_t FFT_GetCenteredSample(uint32_t index)\n",
    "centered-sample accessor",
)

# -------------------------------------------------------------------------
# Core/Src/ui.c
# -------------------------------------------------------------------------
ui_c = replace_once(
    ui_c,
    "static void ui_draw_grid(void);\n",
    """static void ui_draw_grid(void);
static void ui_draw_db_grid(void);
static void ui_draw_db_spectrum_trace(void);
static void ui_draw_db_peak_marker(void);
static int32_t ui_db_tenths_to_y(int16_t db_tenths);
static void ui_draw_signed_db(int32_t x,
                              int32_t y,
                              int16_t db_tenths,
                              uint16_t color);
""",
    "grid prototype",
)

old_spectrum_dispatch = """    ui_draw_grid();

    if (FFT_IsValid())
    {
        ui_draw_spectrum_trace();
        ui_draw_peak_marker();
    }
"""

new_spectrum_dispatch = """    if (ui.mode == UI_MODE_RECORDED_FFT)
    {
        ui_draw_db_grid();

        if (FFT_IsValid())
        {
            ui_draw_db_spectrum_trace();
            ui_draw_db_peak_marker();
        }
    }
    else
    {
        ui_draw_grid();

        if (FFT_IsValid())
        {
            ui_draw_spectrum_trace();
            ui_draw_peak_marker();
        }
    }
"""

ui_c = replace_once(
    ui_c,
    old_spectrum_dispatch,
    new_spectrum_dispatch,
    "spectrum drawing dispatch",
)

ui_helpers = '''static int32_t ui_db_tenths_to_y(int16_t db_tenths)
{
    int32_t value = db_tenths;
    uint32_t usable_height = (uint32_t)UI_GRAPH_HEIGHT - 2U;

    if (value > 0)
    {
        value = 0;
    }
    else if (value < -900)
    {
        value = -900;
    }

    return UI_GRAPH_TOP + 1 +
           (int32_t)(((-value) * usable_height) / 900);
}

static void ui_draw_signed_db(int32_t x,
                              int32_t y,
                              int16_t db_tenths,
                              uint16_t color)
{
    int32_t whole_db = db_tenths / 10;

    if (whole_db < 0)
    {
        Display_DrawString(x, y, "-", color, COLOR_BLACK);
        ui_draw_uint(x + 8, y, (uint32_t)(-whole_db), color);
    }
    else
    {
        ui_draw_uint(x, y, (uint32_t)whole_db, color);
    }
}

static void ui_draw_db_grid(void)
{
    static const int16_t levels[] =
    {
        0,
        -200,
        -400,
        -600,
        -800
    };
    int32_t quarter_width = (int32_t)UI_GRAPH_WIDTH / 4;

    Display_DrawRect(UI_GRAPH_LEFT,
                     UI_GRAPH_TOP,
                     UI_GRAPH_WIDTH,
                     UI_GRAPH_HEIGHT,
                     COLOR_GRAY);

    for (uint32_t index = 0U;
         index < (sizeof(levels) / sizeof(levels[0]));
         index++)
    {
        int32_t y = ui_db_tenths_to_y(levels[index]);

        Display_DrawLine(UI_GRAPH_LEFT,
                         y,
                         UI_GRAPH_RIGHT,
                         y,
                         COLOR_DARK_GRAY);
        ui_draw_signed_db(3, y + 1, levels[index], COLOR_GRAY);
    }

    for (int32_t x = UI_GRAPH_LEFT + quarter_width;
         x < UI_GRAPH_RIGHT;
         x += quarter_width)
    {
        Display_DrawLine(x,
                         UI_GRAPH_TOP,
                         x,
                         UI_GRAPH_BOTTOM,
                         COLOR_DARK_GRAY);
    }

    Display_DrawString(3,
                       UI_GRAPH_TOP + 2,
                       "DBFS",
                       COLOR_CYAN,
                       COLOR_BLACK);
}

static void ui_draw_db_spectrum_trace(void)
{
    uint32_t first_bin = ui.first_bin;
    uint32_t last_bin = ui_last_visible_bin();

    if (last_bin <= first_bin)
    {
        return;
    }

    for (uint32_t bin = first_bin + 1U;
         bin <= last_bin;
         bin++)
    {
        int32_t x0 = ui_bin_to_x(bin - 1U);
        int32_t y0 = ui_db_tenths_to_y(
            FFT_GetDbTenths(bin - 1U));
        int32_t x1 = ui_bin_to_x(bin);
        int32_t y1 = ui_db_tenths_to_y(
            FFT_GetDbTenths(bin));

        Display_DrawLine(x0, y0, x1, y1, COLOR_GREEN);
    }
}

static void ui_draw_db_peak_marker(void)
{
    uint32_t peak_bin = FFT_GetPeakBin();
    uint32_t last_bin = ui_last_visible_bin();
    int32_t peak_x;
    int32_t peak_y;
    int32_t marker_top;

    if ((peak_bin < ui.first_bin) ||
        (peak_bin > last_bin))
    {
        return;
    }

    peak_x = ui_bin_to_x(peak_bin);
    peak_y = ui_db_tenths_to_y(
        FFT_GetPeakDbTenths());
    marker_top = peak_y - 10;

    if (marker_top < UI_GRAPH_TOP)
    {
        marker_top = UI_GRAPH_TOP;
    }

    Display_DrawLine(peak_x,
                     marker_top,
                     peak_x,
                     peak_y,
                     COLOR_RED);
    Display_DrawLine(peak_x - 3,
                     marker_top,
                     peak_x + 3,
                     marker_top,
                     COLOR_RED);

    Display_FillRect(230, 36, 88, 18, COLOR_BLACK);
    Display_DrawString(230, 36, "PK", COLOR_WHITE, COLOR_BLACK);
    ui_draw_signed_db(250,
                      36,
                      FFT_GetPeakDbTenths(),
                      COLOR_YELLOW);
    Display_DrawString(294, 36, "DB", COLOR_GRAY, COLOR_BLACK);
}

'''

ui_c = replace_once(
    ui_c,
    "static void ui_draw_grid(void)\n",
    ui_helpers + "static void ui_draw_grid(void)\n",
    "grid definition",
)

ui_c = replace_once(
    ui_c,
    "/* UI_WAV_RENAME_PATCH */\n",
    """/* UI_WAV_RENAME_PATCH */
/* RECORDED_FFT_DB_DISPLAY_V1_PATCH */
""",
    "UI feature marker",
)

# -------------------------------------------------------------------------
# Validate before writing
# -------------------------------------------------------------------------
outputs = []
for path, text in ((FFT_H, fft_h), (FFT_C, fft_c), (UI_C, ui_c)):
    text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"
    if text.count("{") != text.count("}"):
        fail("Brace mismatch in " + str(path))
    if text.count("/*") != text.count("*/"):
        fail("Comment mismatch in " + str(path))
    if re.search(r"&(lt|gt|amp);|<br", text):
        fail("HTML artifact generated in " + str(path))
    if b"\x00" in text.encode("utf-8"):
        fail("Binary NUL generated in " + str(path))
    outputs.append((path, text))

joined = "\n".join(text for _, text in outputs)
for symbol in (
    MARKER,
    "FFT_GetDbTenths",
    "FFT_GetPeakDbTenths",
    "FFT_DB_REFERENCE_COUNTS",
    "ui_draw_db_grid",
    "ui_draw_db_spectrum_trace",
    "ui_draw_db_peak_marker",
):
    if symbol not in joined:
        fail("Missing generated symbol: " + symbol)

for symbol in (
    "ui_draw_grid();",
    "ui_draw_spectrum_trace();",
    "ui_draw_peak_marker();",
):
    if symbol not in ui_c:
        fail("Live analyzer path was removed: " + symbol)

for path, text in outputs:
    path.write_text(text, encoding="utf-8")

print("Recorded FFT dB display v1 patch applied successfully.")
print("Modified: Core/Inc/fft.h, Core/Src/fft.c, Core/Src/ui.c")
print("Recorded WAV FFT now uses a fixed 0 to -90 dBFS scale.")
print("Live analyzer remains on its existing linear scale.")
print("dB values are cached once per FFT, not during LCD drawing.")
print("Next: make clean && make -j4")
