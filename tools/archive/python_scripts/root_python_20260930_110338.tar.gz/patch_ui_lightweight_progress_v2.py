#!/usr/bin/env python3
"""Install lightweight once-per-second REC progress updates."""
from pathlib import Path
import re, shutil

UH=Path('Core/Inc/ui.h'); UC=Path('Core/Src/ui.c'); MC=Path('Core/Src/main.c')
MARK='UI_LIGHTWEIGHT_PROGRESS_V2_PATCH'

def die(s): raise SystemExit(s)
def one(t,a,b,n):
    c=t.count(a)
    if c!=1: die(f'Expected one {n}, found {c}')
    return t.replace(a,b,1)
def fr(t,s):
    a=t.find(s)
    if a<0: die('Missing function: '+s.strip())
    b=t.find('{',a); d=0
    for i in range(b,len(t)):
        if t[i]=='{': d+=1
        elif t[i]=='}':
            d-=1
            if d==0:
                e=i+1
                while e<len(t) and t[e] in ' \t\r\n': e+=1
                return a,e
    die('Unbalanced function: '+s.strip())

for p in (UH,UC,MC):
    if not p.exists(): die('Missing '+str(p))
    if b'\x00' in p.read_bytes(): die('NUL byte in '+str(p))
h=UH.read_text(); u=UC.read_text(); m=MC.read_text()
for p,t in ((UH,h),(UC,u),(MC,m)):
    if MARK in t: die('Patch already installed in '+str(p))
    if re.search(r'&(lt|gt|amp);|<br',t): die('HTML artifact in '+str(p))
for x in ('UI_MODE_RECORD_DURATION','requested_recording_seconds','UI_REC_SCREEN_FLICKER_POLISH'):
    if x not in h+u+m: die('Missing prerequisite: '+x)
if 'UI_RECORDING_PROGRESS_PATCH' in u:
    die('Restore stable ui.c before applying v2')
for p in (UH,UC,MC):
    q=p.with_name(p.name+'.before_lightweight_progress_v2')
    if not q.exists(): shutil.copy2(p,q)

h=one(h,'void UI_ProcessTouch(void);\n',
'''void UI_ProcessTouch(void);

/* UI_LIGHTWEIGHT_PROGRESS_V2_PATCH */
void UI_ProcessRecorderDisplay(void);
''','touch prototype')

line=next((x for x in u.splitlines(True) if x.startswith('#define UI_FILES_RELEASE_MARGIN')),None)
if line is None: die('Missing UI_FILES_RELEASE_MARGIN')
u=one(u,line,line+'''#define UI_PROGRESS_PERIOD_MS          1000U
#define UI_PROGRESS_REMAIN_X           246
#define UI_PROGRESS_REMAIN_Y           102
#define UI_PROGRESS_REMAIN_W            46U
#define UI_PROGRESS_REMAIN_H            14U
#define UI_PROGRESS_PERCENT_X          260
#define UI_PROGRESS_PERCENT_Y          122
#define UI_PROGRESS_PERCENT_W           32U
#define UI_PROGRESS_PERCENT_H           14U
#define UI_PROGRESS_BAR_X              188
#define UI_PROGRESS_BAR_Y              142
#define UI_PROGRESS_BAR_W              116U
#define UI_PROGRESS_BAR_H               12U
#define UI_PROGRESS_BAR_INNER_X        190
#define UI_PROGRESS_BAR_INNER_Y        144
#define UI_PROGRESS_BAR_INNER_W        112U
#define UI_PROGRESS_BAR_INNER_H          8U
''','geometry line')

u=one(u,'    uint32_t requested_recording_seconds;\n',
'''    uint32_t requested_recording_seconds;
    bool recorder_progress_dirty;
    uint32_t last_progress_draw_ms;
    uint32_t last_progress_percent;
    uint32_t last_remaining_seconds;
''','duration state')
u=one(u,'static void ui_draw_recorder_body(void);\n',
'''static void ui_draw_recorder_body(void);
static void ui_draw_recording_progress_static(void);
static void ui_draw_recording_progress_dynamic(bool force);
static uint32_t ui_recording_target_seconds(void);
''','recorder prototype')

a,b=fr(u,'void UI_Init(void)\n'); f=u[a:b]
f=one(f,'    ui.requested_recording_seconds = 5U;\n',
'''    ui.requested_recording_seconds = 5U;
    ui.recorder_progress_dirty = false;
    ui.last_progress_draw_ms = HAL_GetTick();
    ui.last_progress_percent = 0U;
    ui.last_remaining_seconds = 0U;
''','duration init')
u=u[:a]+f+u[b:]

a,b=fr(u,'void UI_SetRecorderStatus(\n'); f=u[a:b]
old='''    ui.recorder_status = *status;

    if (ui.mode == UI_MODE_RECORDER)
    {
        ui.graph_dirty = true;
    }
}
'''
new='''    {
        bool was_active = ui.recorder_status.capture_active;

        ui.recorder_status = *status;

        if (ui.mode == UI_MODE_RECORDER)
        {
            if (status->capture_active)
            {
                ui.recorder_progress_dirty = true;
            }
            else
            {
                ui.recorder_progress_dirty = false;
                ui.graph_dirty = true;
            }

            if (!was_active && status->capture_active)
            {
                ui.last_progress_draw_ms = HAL_GetTick();
                ui.last_progress_percent = 0U;
                ui.last_remaining_seconds = ui_recording_target_seconds();
                ui.recorder_progress_dirty = true;
            }
        }
    }
}
'''
f=one(f,old,new,'status redraw tail'); u=u[:a]+f+u[b:]

code=r'''static uint32_t ui_recording_target_seconds(void)
{
    uint32_t seconds = ui.requested_recording_seconds;
    if ((seconds != 5U) && (seconds != 10U) &&
        (seconds != 30U) && (seconds != 60U)) seconds = 5U;
    return seconds;
}

static void ui_draw_recording_progress_dynamic(bool force)
{
    uint32_t target_seconds = ui_recording_target_seconds();
    uint64_t target_samples = (uint64_t)target_seconds * 48000U;
    uint32_t captured = ui.recorder_status.captured_samples;
    uint32_t elapsed_seconds = captured / 48000U;
    uint32_t remaining_seconds;
    uint32_t percent;
    uint32_t old_width;
    uint32_t new_width;

    if ((uint64_t)captured >= target_samples)
    {
        remaining_seconds = 0U;
        percent = 100U;
    }
    else
    {
        remaining_seconds = target_seconds - elapsed_seconds;
        percent = (uint32_t)(((uint64_t)captured * 100U) / target_samples);
    }

    if (force || (remaining_seconds != ui.last_remaining_seconds))
    {
        Display_FillRect(UI_PROGRESS_REMAIN_X, UI_PROGRESS_REMAIN_Y,
                         UI_PROGRESS_REMAIN_W, UI_PROGRESS_REMAIN_H, COLOR_BLACK);
        ui_draw_uint(UI_PROGRESS_REMAIN_X, UI_PROGRESS_REMAIN_Y,
                     remaining_seconds, COLOR_YELLOW);
        ui.last_remaining_seconds = remaining_seconds;
    }

    if (force || (percent != ui.last_progress_percent))
    {
        Display_FillRect(UI_PROGRESS_PERCENT_X, UI_PROGRESS_PERCENT_Y,
                         UI_PROGRESS_PERCENT_W, UI_PROGRESS_PERCENT_H, COLOR_BLACK);
        ui_draw_uint(UI_PROGRESS_PERCENT_X, UI_PROGRESS_PERCENT_Y,
                     percent, COLOR_GREEN);
        old_width = (ui.last_progress_percent * UI_PROGRESS_BAR_INNER_W) / 100U;
        new_width = (percent * UI_PROGRESS_BAR_INNER_W) / 100U;
        if (new_width > old_width)
        {
            Display_FillRect(UI_PROGRESS_BAR_INNER_X + (int32_t)old_width,
                             UI_PROGRESS_BAR_INNER_Y, new_width - old_width,
                             UI_PROGRESS_BAR_INNER_H, COLOR_GREEN);
        }
        ui.last_progress_percent = percent;
    }
}

static void ui_draw_recording_progress_static(void)
{
    uint32_t target = ui_recording_target_seconds();
    Display_DrawString(188, 82, "TARGET", COLOR_WHITE, COLOR_BLACK);
    ui_draw_uint(246, 82, target, COLOR_CYAN);
    Display_DrawString(278, 82, "SEC", COLOR_GRAY, COLOR_BLACK);
    Display_DrawString(188, 102, "REMAIN", COLOR_WHITE, COLOR_BLACK);
    Display_DrawString(292, 102, "SEC", COLOR_GRAY, COLOR_BLACK);
    Display_DrawString(188, 122, "PROGRESS", COLOR_WHITE, COLOR_BLACK);
    Display_DrawString(292, 122, "%", COLOR_GRAY, COLOR_BLACK);
    Display_DrawRect(UI_PROGRESS_BAR_X, UI_PROGRESS_BAR_Y,
                     UI_PROGRESS_BAR_W, UI_PROGRESS_BAR_H, COLOR_WHITE);
    Display_FillRect(UI_PROGRESS_BAR_INNER_X, UI_PROGRESS_BAR_INNER_Y,
                     UI_PROGRESS_BAR_INNER_W, UI_PROGRESS_BAR_INNER_H,
                     COLOR_DARK_GRAY);
    ui.last_progress_percent = 0U;
    ui.last_remaining_seconds = target;
    ui_draw_recording_progress_dynamic(true);
}

void UI_ProcessRecorderDisplay(void)
{
    uint32_t now;
    if (!ui.initialized || (ui.mode != UI_MODE_RECORDER) ||
        !ui.recorder_status.capture_active || !ui.recorder_progress_dirty) return;
    now = HAL_GetTick();
    if ((now - ui.last_progress_draw_ms) < UI_PROGRESS_PERIOD_MS) return;
    ui.last_progress_draw_ms = now;
    ui.recorder_progress_dirty = false;
    ui_draw_recording_progress_dynamic(false);
}

'''
u=one(u,'static void ui_draw_recorder_body(void)\n',code+'static void ui_draw_recorder_body(void)\n','body definition')

a,b=fr(u,'static void ui_draw_recorder_body(void)\n'); f=u[a:b]
anchor='''    Display_FillRect(UI_FILES_X, UI_FILES_Y,
                     UI_FILES_WIDTH, UI_FILES_HEIGHT, COLOR_BLUE);
'''
f=one(f,anchor,'    ui_draw_recording_progress_static();\n\n'+anchor,'FILES drawing')
u=u[:a]+f+u[b:]
u=one(u,'/* UI_WAV_RENAME_PATCH */\n','/* UI_WAV_RENAME_PATCH */\n/* UI_LIGHTWEIGHT_PROGRESS_V2_PATCH */\n','UI marker')

m=one(m,'/* UI_RECORD_DURATION_SELECTOR_PATCH */\n','/* UI_RECORD_DURATION_SELECTOR_PATCH */\n/* UI_LIGHTWEIGHT_PROGRESS_V2_PATCH */\n','main marker')
oldloop='''    UI_UpdateRecorderStatus();

    /* Service recording again after possible display work. */
    Capture_ProcessRecorder();
    Recorder_Process();
'''
newloop='''    UI_UpdateRecorderStatus();

    /* Service audio immediately before the tiny progress update. */
    Capture_ProcessRecorder();
    Recorder_Process();

    UI_ProcessRecorderDisplay();

    /* Service audio again immediately after display work. */
    Capture_ProcessRecorder();
    Recorder_Process();
'''
m=one(m,oldloop,newloop,'main loop display block')

outs=[]
for p,t in ((UH,h),(UC,u),(MC,m)):
    t='\n'.join(x.rstrip() for x in t.splitlines())+'\n'
    if t.count('{')!=t.count('}'): die('Brace mismatch in '+str(p))
    if t.count('/*')!=t.count('*/'): die('Comment mismatch in '+str(p))
    if re.search(r'&(lt|gt|amp);|<br',t): die('HTML artifact in output '+str(p))
    if b'\x00' in t.encode(): die('NUL generated in '+str(p))
    outs.append((p,t))
alltext='\n'.join(t for _,t in outs)
for x in (MARK,'UI_ProcessRecorderDisplay','ui_draw_recording_progress_dynamic',
          'UI_PROGRESS_PERIOD_MS','recorder_progress_dirty','new_width > old_width'):
    if x not in alltext: die('Missing generated symbol: '+x)
if 'UI_RECORDING_PROGRESS_PATCH' in alltext: die('Old progress marker in output')
for p,t in outs: p.write_text(t)
print('Lightweight recording progress v2 patch applied successfully.')
print('Modified: Core/Inc/ui.h, Core/Src/ui.c, Core/Src/main.c')
print('Updates remaining seconds, percentage, and bar delta once per second.')
print('Full REC-body redraws are suppressed while capture is active.')
print('DMA and recorder service run immediately before and after LCD work.')
print('Next: make clean && make -j4')
