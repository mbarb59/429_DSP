#!/usr/bin/env python3
"""Safely organize generated 429_DSP backups and patch scripts.

Default mode is a dry run. Use --apply to perform the moves/removals.
Active Core *.c and *.h files with normal filenames are never touched.
"""

from pathlib import Path
import argparse
import shutil
import sys

ROOT = Path.cwd()
CORE = ROOT / "Core"
TOOLS = ROOT / "tools"
ARCHIVE = TOOLS / "archive" / "source_backups"
PATCHES = TOOLS / "patches"
EXPERIMENTS = TOOLS / "experiments"

BACKUP_MARKERS = (
    ".before_",
    ".experimental_",
    ".rollback_",
)
BACKUP_SUFFIXES = (".bak", ".orig", "~")

PATCH_NAMES = {
    "patch_recording_space_check.py",
    "patch_ui_delete_confirmation.py",
    "patch_ui_sd_space_low_message.py",
    "patch_ui_wav_rename.py",
    "patch_ui_lightweight_progress_v2.py",
}

EXPERIMENT_SCRIPT_NAMES = {
    "rollback_wav_preallocation_v1.py",
    "patch_wav_preallocation_v1.py",
    "patch_ui_recording_progress.py",
}


def is_generated_backup(path: Path) -> bool:
    name = path.name
    return any(marker in name for marker in BACKUP_MARKERS) or any(
        name.endswith(suffix) for suffix in BACKUP_SUFFIXES
    )


def destination_for_backup(path: Path) -> Path:
    rel = path.relative_to(ROOT)
    if ".experimental_wav_preallocation_v1" in path.name:
        return (
            EXPERIMENTS
            / "wav_preallocation_v1"
            / "source_snapshots"
            / rel
        )
    if ".experimental_recording_progress" in path.name:
        return (
            EXPERIMENTS
            / "recording_progress_v1"
            / "source_snapshots"
            / rel
        )
    return ARCHIVE / rel


def unique_destination(destination: Path) -> Path:
    if not destination.exists():
        return destination
    counter = 1
    while True:
        candidate = destination.with_name(
            destination.name + f".duplicate_{counter}"
        )
        if not candidate.exists():
            return candidate
        counter += 1


def move_file(source: Path, destination: Path, apply: bool) -> None:
    destination = unique_destination(destination)
    print(f"MOVE   {source.relative_to(ROOT)}")
    print(f"    -> {destination.relative_to(ROOT)}")
    if apply:
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(source), str(destination))


def remove_cache(path: Path, apply: bool) -> None:
    print(f"REMOVE {path.relative_to(ROOT)}")
    if apply:
        if path.is_dir():
            shutil.rmtree(path)
        else:
            path.unlink()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--apply",
        action="store_true",
        help="perform the planned cleanup; default is dry-run",
    )
    args = parser.parse_args()

    if not CORE.is_dir() or not (ROOT / "Makefile").exists():
        print("Run this script from the ~/429_DSP project root.", file=sys.stderr)
        return 2

    backups = sorted(
        path for path in CORE.rglob("*")
        if path.is_file() and is_generated_backup(path)
    )

    root_python = sorted(ROOT.glob("*.py"))
    patch_scripts = [p for p in root_python if p.name in PATCH_NAMES]
    experiment_scripts = [
        p for p in root_python if p.name in EXPERIMENT_SCRIPT_NAMES
    ]

    caches = sorted(ROOT.rglob("__pycache__"))
    pyc_files = sorted(ROOT.rglob("*.pyc"))

    print("429_DSP generated-file cleanup")
    print("Mode:", "APPLY" if args.apply else "DRY RUN")
    print()

    for path in backups:
        move_file(path, destination_for_backup(path), args.apply)

    for path in patch_scripts:
        move_file(path, PATCHES / path.name, args.apply)

    for path in experiment_scripts:
        if "preallocation" in path.name:
            destination = EXPERIMENTS / "wav_preallocation_v1" / path.name
        else:
            destination = EXPERIMENTS / "recording_progress_v1" / path.name
        move_file(path, destination, args.apply)

    for path in caches:
        remove_cache(path, args.apply)
    for path in pyc_files:
        if path.exists():
            remove_cache(path, args.apply)

    print()
    print(f"Backup/experimental source files: {len(backups)}")
    print(f"Production patch scripts:         {len(patch_scripts)}")
    print(f"Experiment scripts:               {len(experiment_scripts)}")
    print(f"Python cache directories:         {len(caches)}")
    print(f"Python bytecode files:             {len(pyc_files)}")

    if not args.apply:
        print()
        print("Dry run only. Review the list, then run:")
        print("  python3 cleanup_429_dsp_generated_files.py --apply")
    else:
        print()
        print("Cleanup organization completed.")
        print("Active normal-name Core .c/.h files were not touched.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
