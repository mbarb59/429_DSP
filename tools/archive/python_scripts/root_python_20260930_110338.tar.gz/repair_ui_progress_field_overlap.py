#!/usr/bin/env python3
"""Remove legacy REC fields that overlap lightweight progress values."""

from pathlib import Path
import re
import shutil

UI_C = Path("Core/Src/ui.c")
MARKER = "UI_PROGRESS_FIELD_OVERLAP_FIX"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


if not UI_C.exists():
    fail(f"Missing required file: {UI_C}")

raw = UI_C.read_bytes()
if b"\x00" in raw:
    fail("Binary NUL found in Core/Src/ui.c")

text = raw.decode("utf-8")

if MARKER in text:
    fail("Progress field-overlap fix is already installed")

if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact found in Core/Src/ui.c")

for prerequisite in (
    "UI_LIGHTWEIGHT_PROGRESS_V2_PATCH",
    "UI_LIGHTWEIGHT_PROGRESS_RESET_FIX",
    "ui_draw_recording_progress_static();",
    "UI_PROGRESS_REMAIN_X",
    "UI_SD_SPACE_LOW_MESSAGE_PATCH",
):
    if prerequisite not in text:
        fail("Missing prerequisite: " + prerequisite)

backup = UI_C.with_name(UI_C.name + ".before_progress_field_overlap_fix")
if not backup.exists():
    shutil.copy2(UI_C, backup)

legacy_block = '''    Display_DrawString(188, 62,
                       ui.recorder_status.capture_active ?
                       "CAPTURE ON" : "CAPTURE OFF",
                       ui.recorder_status.capture_active ?
                       COLOR_RED : COLOR_GREEN,
                       COLOR_BLACK);

    Display_DrawString(188, 82, "SELECTED WAV", COLOR_WHITE, COLOR_BLACK);
    Display_DrawString(188, 102, "RMS", COLOR_WHITE, COLOR_BLACK);
    ui_draw_uint(230, 102,
                 ui.recorder_status.rms_counts,
                 COLOR_YELLOW);

    Display_DrawString(188, 122, "CLIP", COLOR_WHITE, COLOR_BLACK);
    Display_DrawString(230, 122,
                       ui.recorder_status.clipping ? "YES" : "NO",
                       ui.recorder_status.clipping ? COLOR_RED : COLOR_GREEN,
                       COLOR_BLACK);

    Display_DrawString(188, 142, "CLIP CNT", COLOR_WHITE, COLOR_BLACK);
    ui_draw_uint(248, 142,
                 ui.recorder_status.clip_count,
                 ui.recorder_status.clipping ? COLOR_RED : COLOR_YELLOW);


'''

replacement_block = '''    /* UI_PROGRESS_FIELD_OVERLAP_FIX
     * Keep MIC RMS on its own row. The legacy SELECTED WAV, RMS, CLIP,
     * and CLIP CNT rows overlapped TARGET, REMAIN, PROGRESS, and the bar.
     */
    Display_DrawString(188, 62, "MIC RMS", COLOR_WHITE, COLOR_BLACK);
    ui_draw_uint(248, 62,
                 ui.recorder_status.rms_counts,
                 COLOR_YELLOW);
    Display_DrawString(292, 62,
                       ui.recorder_status.clipping ? "!" : "OK",
                       ui.recorder_status.clipping ? COLOR_RED : COLOR_GREEN,
                       COLOR_BLACK);

'''

text = once(
    text,
    legacy_block,
    replacement_block,
    "legacy right-side recorder block",
)

# Draw normal progress first, then overlay SD SPACE LOW when needed. This keeps
# the warning readable and prevents progress labels from repainting over it.
old_order = '''    if (ui.recorder_space_low &&
        !ui.recorder_status.capture_active)
    {
        Display_FillRect(176, 58, 136, 100, COLOR_BLACK);
        Display_DrawRect(176, 58, 136, 100, COLOR_RED);
        Display_DrawString(188, 68, "SD SPACE LOW", COLOR_RED, COLOR_BLACK);
        Display_DrawString(184, 94, "REQUIRED", COLOR_WHITE, COLOR_BLACK);
        ui_draw_uint(250, 94, ui.recorder_required_kib, COLOR_YELLOW);
        Display_DrawString(292, 94, "K", COLOR_GRAY, COLOR_BLACK);
        Display_DrawString(184, 118, "AVAILABLE", COLOR_WHITE, COLOR_BLACK);
        ui_draw_uint(250, 118, ui.recorder_available_kib, COLOR_YELLOW);
        Display_DrawString(292, 118, "K", COLOR_GRAY, COLOR_BLACK);
        Display_DrawString(188, 142, "DELETE FILES", COLOR_WHITE, COLOR_BLACK);
    }

    ui_draw_recording_progress_static();

'''

new_order = '''    ui_draw_recording_progress_static();

    if (ui.recorder_space_low &&
        !ui.recorder_status.capture_active)
    {
        Display_FillRect(176, 58, 136, 100, COLOR_BLACK);
        Display_DrawRect(176, 58, 136, 100, COLOR_RED);
        Display_DrawString(188, 68, "SD SPACE LOW", COLOR_RED, COLOR_BLACK);
        Display_DrawString(184, 94, "REQUIRED", COLOR_WHITE, COLOR_BLACK);
        ui_draw_uint(250, 94, ui.recorder_required_kib, COLOR_YELLOW);
        Display_DrawString(292, 94, "K", COLOR_GRAY, COLOR_BLACK);
        Display_DrawString(184, 118, "AVAILABLE", COLOR_WHITE, COLOR_BLACK);
        ui_draw_uint(250, 118, ui.recorder_available_kib, COLOR_YELLOW);
        Display_DrawString(292, 118, "K", COLOR_GRAY, COLOR_BLACK);
        Display_DrawString(188, 142, "DELETE FILES", COLOR_WHITE, COLOR_BLACK);
    }

'''

text = once(text, old_order, new_order, "progress and warning draw order")

text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"

if text.count("{") != text.count("}"):
    fail("Brace balance failed")
if text.count("/*") != text.count("*/"):
    fail("Comment balance failed")
if b"\x00" in text.encode("utf-8"):
    fail("Binary NUL generated")

for removed in (
    'Display_DrawString(188, 82, "SELECTED WAV"',
    'Display_DrawString(188, 102, "RMS"',
    'Display_DrawString(188, 122, "CLIP"',
    'Display_DrawString(188, 142, "CLIP CNT"',
):
    if removed in text:
        fail("Legacy overlapping field remains: " + removed)

for required in (
    MARKER,
    'Display_DrawString(188, 62, "MIC RMS"',
    "ui_draw_recording_progress_static();",
    '"SD SPACE LOW"',
):
    if required not in text:
        fail("Missing generated symbol: " + required)

UI_C.write_text(text, encoding="utf-8")

print("REC progress field-overlap repair applied successfully.")
print("Removed legacy SELECTED WAV, RMS, CLIP, and CLIP CNT overlap.")
print("MIC RMS remains on the dedicated top-right row.")
print("SD SPACE LOW now overlays progress instead of being overwritten.")
print("No recording-time update rate or DMA logic was changed.")
print("Next: make clean && make -j4")
