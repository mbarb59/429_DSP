#!/usr/bin/env python3
"""Add a tap-and-drag timeline scrubber to recorded-WAV FFT mode.

The cursor previews while dragging. The WAV segment is read and its FFT is
calculated only once, when the touch is released.
"""

from pathlib import Path
import re
import shutil

UI_H = Path("Core/Inc/ui.h")
UI_C = Path("Core/Src/ui.c")
MAIN_C = Path("Core/Src/main.c")
WAV_H = Path("Core/Inc/wav_fft_viewer.h")
WAV_C = Path("Core/Src/wav_fft_viewer.c")
MARKER = "RECORDED_FFT_TIMELINE_SCRUBBER_PATCH"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


def backup(path):
    target = path.with_name(path.name + ".before_recorded_fft_timeline")
    if not target.exists():
        shutil.copy2(path, target)


paths = (UI_H, UI_C, MAIN_C, WAV_H, WAV_C)
for path in paths:
    if not path.exists():
        fail("Missing required file: " + str(path))
    if b"\x00" in path.read_bytes():
        fail("Binary NUL found in " + str(path))

ui_h = UI_H.read_text(encoding="utf-8")
ui_c = UI_C.read_text(encoding="utf-8")
main_c = MAIN_C.read_text(encoding="utf-8")
wav_h = WAV_H.read_text(encoding="utf-8")
wav_c = WAV_C.read_text(encoding="utf-8")

for path, text in zip(paths, (ui_h, ui_c, main_c, wav_h, wav_c)):
    if MARKER in text:
        fail("Timeline scrubber is already installed in " + str(path))
    if re.search(r"&(lt|gt|amp);|<br", text):
        fail("HTML artifact found in " + str(path))

combined = ui_h + ui_c + main_c + wav_h + wav_c
for symbol in (
    "RECORDED_FFT_DB_DISPLAY_V1_PATCH",
    "FFT_PEAK_FREQUENCY_UNITS_PATCH",
    "UI_MODE_RECORDED_FFT",
    "WavFftViewer_LoadNext",
    "static FRESULT load_segment(uint32_t segment_index)",
    "UI_ACTION_FFT_NEXT",
):
    if symbol not in combined:
        fail("Missing prerequisite: " + symbol)

for path in paths:
    backup(path)

# -------------------------------------------------------------------------
# WAV viewer direct segment API
# -------------------------------------------------------------------------
wav_h = once(
    wav_h,
    "FRESULT WavFftViewer_LoadNext(void);\n",
    """FRESULT WavFftViewer_LoadNext(void);

/* RECORDED_FFT_TIMELINE_SCRUBBER_PATCH */
FRESULT WavFftViewer_LoadSegment(uint32_t segment_index);
""",
    "WAV FFT next prototype",
)

load_api = '''FRESULT WavFftViewer_LoadSegment(uint32_t segment_index)
{
    if (!info.active || (info.segment_count == 0U))
    {
        return FR_INVALID_OBJECT;
    }

    if (segment_index >= info.segment_count)
    {
        segment_index = info.segment_count - 1U;
    }

    return load_segment(segment_index);
}

'''
wav_c = once(
    wav_c,
    "FRESULT WavFftViewer_LoadPrevious(void)\n",
    load_api + "FRESULT WavFftViewer_LoadPrevious(void)\n",
    "WAV FFT previous implementation",
)

# -------------------------------------------------------------------------
# Public UI action and accessor
# -------------------------------------------------------------------------
ui_h = once(
    ui_h,
    "    UI_ACTION_FFT_NEXT,\n",
    """    UI_ACTION_FFT_NEXT,
    UI_ACTION_FFT_LOAD_SEGMENT,
""",
    "FFT next action",
)

ui_h = once(
    ui_h,
    "UI_Action UI_GetPendingAction(void);\n",
    """UI_Action UI_GetPendingAction(void);

/* RECORDED_FFT_TIMELINE_SCRUBBER_PATCH */
uint32_t UI_GetRequestedFftSegment(void);
""",
    "pending action accessor",
)

# -------------------------------------------------------------------------
# UI geometry and state
# -------------------------------------------------------------------------
geometry_anchor = "#define UI_GRAPH_HEIGHT            (UI_GRAPH_BOTTOM - UI_GRAPH_TOP + 1)\n"
ui_c = once(
    ui_c,
    geometry_anchor,
    geometry_anchor + """#define UI_FFT_TIMELINE_X                 20
#define UI_FFT_TIMELINE_Y                196
#define UI_FFT_TIMELINE_WIDTH            280U
#define UI_FFT_TIMELINE_HEIGHT            18U
#define UI_FFT_TIMELINE_LINE_Y           205
#define UI_FFT_TIMELINE_TOUCH_MARGIN       4U
""",
    "graph geometry tail",
)

ui_c = once(
    ui_c,
    "    uint32_t magnitude_max;\n",
    """    uint32_t magnitude_max;
    bool fft_timeline_dragging;
    uint32_t fft_timeline_preview_segment;
    uint32_t requested_fft_segment;
""",
    "FFT view state",
)

# Initialize timeline state only inside UI_Init(). The same magnitude
# assignment appears elsewhere, so a global replace would be ambiguous.
ui_init_start = ui_c.find("void UI_Init(void)\n")
ui_init_end = ui_c.find("void UI_Draw(void)\n", ui_init_start)

if ui_init_start < 0 or ui_init_end < 0:
    fail("Could not isolate UI_Init")

ui_init = ui_c[ui_init_start:ui_init_end]
ui_init = once(
    ui_init,
    "    ui.magnitude_max = UI_DEFAULT_MAGNITUDE_MAX;\n",
    """    ui.magnitude_max = UI_DEFAULT_MAGNITUDE_MAX;
    ui.fft_timeline_dragging = false;
    ui.fft_timeline_preview_segment = 0U;
    ui.requested_fft_segment = 0U;
""",
    "FFT view initialization inside UI_Init",
)
ui_c = ui_c[:ui_init_start] + ui_init + ui_c[ui_init_end:]

ui_c = once(
    ui_c,
    "static void ui_draw_db_peak_marker(void);\n",
    """static void ui_draw_db_peak_marker(void);
static void ui_draw_fft_timeline(void);
static bool ui_fft_timeline_contains(uint16_t x, uint16_t y);
static uint32_t ui_fft_timeline_segment_from_x(uint16_t x);
""",
    "dB peak marker prototype",
)

# Accessor inserted before the existing recorder status setter.
accessor = '''uint32_t UI_GetRequestedFftSegment(void)
{
    return ui.requested_fft_segment;
}

'''
ui_c = once(
    ui_c,
    "void UI_SetRecorderStatus(\n",
    accessor + "void UI_SetRecorderStatus(\n",
    "recorder status setter",
)

# Reset timeline preview whenever recorded FFT mode is shown after a load.
ui_c = once(
    ui_c,
    """    ui.mode = UI_MODE_RECORDED_FFT;
    ui.running = false;
    ui_apply_full_span();
""",
    """    ui.mode = UI_MODE_RECORDED_FFT;
    ui.running = false;
    ui.fft_timeline_dragging = false;
    ui.fft_timeline_preview_segment =
        WavFftViewer_GetInfo()->segment_index;
    ui.requested_fft_segment =
        ui.fft_timeline_preview_segment;
    ui_apply_full_span();
""",
    "recorded FFT screen setup",
)

# Draw timeline last so its black strip and cursor remain visible over the FFT.
ui_c = once(
    ui_c,
    """            ui_draw_db_spectrum_trace();
            ui_draw_db_peak_marker();
""",
    """            ui_draw_db_spectrum_trace();
            ui_draw_db_peak_marker();
            ui_draw_fft_timeline();
""",
    "recorded FFT dB drawing",
)

helpers = '''static bool ui_fft_timeline_contains(uint16_t x, uint16_t y)
{
    return (x >= UI_FFT_TIMELINE_X) &&
           (x < (UI_FFT_TIMELINE_X + UI_FFT_TIMELINE_WIDTH)) &&
           ((uint32_t)y + UI_FFT_TIMELINE_TOUCH_MARGIN >=
            UI_FFT_TIMELINE_Y) &&
           (y < (UI_FFT_TIMELINE_Y + UI_FFT_TIMELINE_HEIGHT +
                 UI_FFT_TIMELINE_TOUCH_MARGIN));
}

static uint32_t ui_fft_timeline_segment_from_x(uint16_t x)
{
    const WavFftViewerInfo *info = WavFftViewer_GetInfo();
    uint32_t relative_x;

    if ((info == NULL) || !info->active ||
        (info->segment_count <= 1U))
    {
        return 0U;
    }

    if (x <= UI_FFT_TIMELINE_X)
    {
        return 0U;
    }

    if (x >= (UI_FFT_TIMELINE_X + UI_FFT_TIMELINE_WIDTH - 1U))
    {
        return info->segment_count - 1U;
    }

    relative_x = x - UI_FFT_TIMELINE_X;

    return (uint32_t)(
        ((uint64_t)relative_x * (info->segment_count - 1U)) /
        (UI_FFT_TIMELINE_WIDTH - 1U));
}

static void ui_draw_fft_timeline(void)
{
    const WavFftViewerInfo *info = WavFftViewer_GetInfo();
    uint32_t segment_index;
    int32_t cursor_x;

    if ((info == NULL) || !info->active ||
        (info->segment_count == 0U))
    {
        return;
    }

    segment_index = ui.fft_timeline_dragging ?
        ui.fft_timeline_preview_segment : info->segment_index;

    if (info->segment_count <= 1U)
    {
        cursor_x = UI_FFT_TIMELINE_X;
    }
    else
    {
        cursor_x = UI_FFT_TIMELINE_X + (int32_t)(
            ((uint64_t)segment_index *
             (UI_FFT_TIMELINE_WIDTH - 1U)) /
            (info->segment_count - 1U));
    }

    Display_FillRect(UI_FFT_TIMELINE_X - 2,
                     UI_FFT_TIMELINE_Y,
                     UI_FFT_TIMELINE_WIDTH + 4U,
                     UI_FFT_TIMELINE_HEIGHT,
                     COLOR_BLACK);
    Display_DrawLine(UI_FFT_TIMELINE_X,
                     UI_FFT_TIMELINE_LINE_Y,
                     UI_FFT_TIMELINE_X +
                         (int32_t)UI_FFT_TIMELINE_WIDTH - 1,
                     UI_FFT_TIMELINE_LINE_Y,
                     COLOR_GRAY);
    Display_DrawLine(cursor_x,
                     UI_FFT_TIMELINE_Y + 2,
                     cursor_x,
                     UI_FFT_TIMELINE_Y +
                         (int32_t)UI_FFT_TIMELINE_HEIGHT - 3,
                     ui.fft_timeline_dragging ? COLOR_YELLOW : COLOR_WHITE);
    Display_DrawLine(cursor_x - 2,
                     UI_FFT_TIMELINE_Y + 2,
                     cursor_x + 2,
                     UI_FFT_TIMELINE_Y + 2,
                     ui.fft_timeline_dragging ? COLOR_YELLOW : COLOR_WHITE);
}

'''
ui_c = once(
    ui_c,
    "static void ui_draw_db_grid(void)\n",
    helpers + "static void ui_draw_db_grid(void)\n",
    "dB grid implementation",
)

# Touch down: capture timeline before normal graph gestures.
ui_c = once(
    ui_c,
    """    ui.touch_armed = false;
    ui.pressed_button = ui_hit_test_button(touch->x, touch->y);
""",
    """    ui.touch_armed = false;

    if ((ui.mode == UI_MODE_RECORDED_FFT) &&
        ui_fft_timeline_contains(touch->x, touch->y))
    {
        ui.fft_timeline_dragging = true;
        ui.fft_timeline_preview_segment =
            ui_fft_timeline_segment_from_x(touch->x);
        ui.requested_fft_segment =
            ui.fft_timeline_preview_segment;
        ui.graph_dirty = true;
        ui.pressed_button = UI_BUTTON_NONE;
    }
    else
    {
        ui.pressed_button = ui_hit_test_button(touch->x, touch->y);
    }
""",
    "touch-down button capture",
)

# Touch move: preview only; no SD read or FFT processing.
move_anchor = """    if ((ui.mode == UI_MODE_ANALYZER) &&
        (ui.touch_start_y >= UI_GRAPH_TOP) &&
        (ui.touch_start_y <= UI_GRAPH_BOTTOM))
"""
move_replacement = """    if ((ui.mode == UI_MODE_RECORDED_FFT) &&
        ui.fft_timeline_dragging)
    {
        ui.fft_timeline_preview_segment =
            ui_fft_timeline_segment_from_x(touch->x);
        ui.requested_fft_segment =
            ui.fft_timeline_preview_segment;
        ui.graph_dirty = true;
    }
    else if ((ui.mode == UI_MODE_ANALYZER) &&
        (ui.touch_start_y >= UI_GRAPH_TOP) &&
        (ui.touch_start_y <= UI_GRAPH_BOTTOM))
"""
ui_c = once(ui_c, move_anchor, move_replacement, "touch-move analyzer branch")

# Touch release gets priority and emits exactly one deferred load action.
release_anchor = """    /* UI_FILES_TOUCH_FIX
     * Require the press to begin inside FILES, but allow the release
"""
release_replacement = """    if ((ui.mode == UI_MODE_RECORDED_FFT) &&
        ui.fft_timeline_dragging)
    {
        ui.requested_fft_segment =
            ui.fft_timeline_preview_segment;
        ui.pending_action = UI_ACTION_FFT_LOAD_SEGMENT;
        ui.fft_timeline_dragging = false;
        UART_SendString("UI RECORDED FFT TIMELINE REQUEST\\r\\n");
        action_executed = true;
    }
    /* UI_FILES_TOUCH_FIX
     * Require the press to begin inside FILES, but allow the release
"""
ui_c = once(ui_c, release_anchor, release_replacement, "touch-up first branch")

# The existing FILES branch follows the inserted if, so change its first if to
# else-if to preserve one-action-only behavior.
ui_c = once(
    ui_c,
    """     */
    if ((ui.mode == UI_MODE_RECORDER) &&
""",
    """     */
    else if ((ui.mode == UI_MODE_RECORDER) &&
""",
    "FILES touch branch after timeline",
)

ui_c = once(
    ui_c,
    "/* FFT_PEAK_UNITS_NO_STDIO_FIX */\n",
    """/* FFT_PEAK_UNITS_NO_STDIO_FIX */
/* RECORDED_FFT_TIMELINE_SCRUBBER_PATCH */
""",
    "FFT peak unit marker",
)

# -------------------------------------------------------------------------
# Main foreground action: one load after release
# -------------------------------------------------------------------------
new_case = '''        case UI_ACTION_FFT_LOAD_SEGMENT:
            result = WavFftViewer_LoadSegment(
                UI_GetRequestedFftSegment());
            if (result == FR_OK)
            {
                UI_ShowRecordedFft();
            }
            else
            {
                UART_SendString("UI recorded FFT timeline failed, FatFs = ");
                UART_SendDec((uint32_t)result);
                UART_SendString("\\r\\n");
            }
            break;

'''
main_c = once(
    main_c,
    "        case UI_ACTION_FFT_BACK:\n",
    new_case + "        case UI_ACTION_FFT_BACK:\n",
    "FFT back action case",
)

main_c = once(
    main_c,
    "/* UI_RECORDED_FFT_PATCH */\n",
    """/* UI_RECORDED_FFT_PATCH */
/* RECORDED_FFT_TIMELINE_SCRUBBER_PATCH */
""",
    "recorded FFT main marker",
)

# -------------------------------------------------------------------------
# Validation and write
# -------------------------------------------------------------------------
outputs = []
for path, text in (
    (UI_H, ui_h),
    (UI_C, ui_c),
    (MAIN_C, main_c),
    (WAV_H, wav_h),
    (WAV_C, wav_c),
):
    text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"
    if text.count("{") != text.count("}"):
        fail("Brace mismatch in " + str(path))
    if text.count("/*") != text.count("*/"):
        fail("Comment mismatch in " + str(path))
    if re.search(r"&(lt|gt|amp);|<br", text):
        fail("HTML artifact generated in " + str(path))
    if b"\x00" in text.encode("utf-8"):
        fail("Binary NUL generated in " + str(path))
    outputs.append((path, text))

joined = "\n".join(text for _, text in outputs)
for symbol in (
    MARKER,
    "WavFftViewer_LoadSegment",
    "UI_ACTION_FFT_LOAD_SEGMENT",
    "UI_GetRequestedFftSegment",
    "ui_draw_fft_timeline",
    "fft_timeline_dragging",
):
    if symbol not in joined:
        fail("Missing generated symbol: " + symbol)

if main_c.count("case UI_ACTION_FFT_LOAD_SEGMENT:") != 1:
    fail("Timeline action case missing or duplicated")
if wav_c.count("FRESULT WavFftViewer_LoadSegment(") != 1:
    fail("Direct segment API missing or duplicated")

for path, text in outputs:
    path.write_text(text, encoding="utf-8")

print("Recorded FFT timeline scrubber patch applied successfully.")
print("Tap or drag the timeline; WAV segment loads once on release.")
print("PREV, NEXT, FULL, PEAK, dBFS, and Hz/kHz formatting remain active.")
print("Recorder, DMA, and SD write paths were unchanged.")
print("Next: make clean && make -j4")
