#!/usr/bin/env python3
"""Replace snprintf-based FFT peak formatting with a tiny freestanding formatter."""

from pathlib import Path
import re
import shutil

UI_C = Path("Core/Src/ui.c")
MARKER = "FFT_PEAK_UNITS_NO_STDIO_FIX"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


if not UI_C.exists():
    fail(f"Missing required file: {UI_C}")

raw = UI_C.read_bytes()
if b"\x00" in raw:
    fail("Binary NUL found in Core/Src/ui.c")

text = raw.decode("utf-8")

if MARKER in text:
    fail("No-stdio peak-format repair is already installed")

if "FFT_PEAK_FREQUENCY_UNITS_PATCH" not in text:
    fail("Missing prerequisite: FFT_PEAK_FREQUENCY_UNITS_PATCH")

if "snprintf" not in text or "#include <stdio.h>" not in text:
    fail("Expected snprintf-based formatter was not found")

if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact found in Core/Src/ui.c")

backup = UI_C.with_name(UI_C.name + ".before_peak_units_no_stdio_fix")
if not backup.exists():
    shutil.copy2(UI_C, backup)

text = once(
    text,
    "#include <stdio.h>\n",
    "",
    "stdio include",
)

old_helper = r'''static void ui_format_peak_frequency(uint32_t frequency_hz,
                                     char *buffer,
                                     uint32_t buffer_size)
{
    if ((buffer == NULL) || (buffer_size == 0U))
    {
        return;
    }

    if (frequency_hz < 1000U)
    {
        (void)snprintf(buffer,
                       buffer_size,
                       "%lu Hz",
                       (unsigned long)frequency_hz);
    }
    else if (frequency_hz < 10000U)
    {
        uint32_t rounded_hundredths =
            (frequency_hz + 5U) / 10U;
        uint32_t whole_khz = rounded_hundredths / 100U;
        uint32_t fraction = rounded_hundredths % 100U;

        (void)snprintf(buffer,
                       buffer_size,
                       "%lu.%02lu kHz",
                       (unsigned long)whole_khz,
                       (unsigned long)fraction);
    }
    else
    {
        uint32_t rounded_tenths =
            (frequency_hz + 50U) / 100U;
        uint32_t whole_khz = rounded_tenths / 10U;
        uint32_t fraction = rounded_tenths % 10U;

        (void)snprintf(buffer,
                       buffer_size,
                       "%lu.%01lu kHz",
                       (unsigned long)whole_khz,
                       (unsigned long)fraction);
    }

    buffer[buffer_size - 1U] = '\0';
}

'''

new_helper = r'''static uint32_t ui_append_uint_text(char *buffer,
                                    uint32_t buffer_size,
                                    uint32_t position,
                                    uint32_t value,
                                    uint32_t minimum_digits)
{
    char reverse[10];
    uint32_t count = 0U;

    do
    {
        reverse[count++] = (char)('0' + (value % 10U));
        value /= 10U;
    }
    while ((value != 0U) && (count < sizeof(reverse)));

    while ((count < minimum_digits) &&
           (count < sizeof(reverse)))
    {
        reverse[count++] = '0';
    }

    while ((count != 0U) &&
           ((position + 1U) < buffer_size))
    {
        buffer[position++] = reverse[--count];
    }

    buffer[position] = '\0';
    return position;
}

static uint32_t ui_append_text(char *buffer,
                               uint32_t buffer_size,
                               uint32_t position,
                               const char *text)
{
    while ((*text != '\0') &&
           ((position + 1U) < buffer_size))
    {
        buffer[position++] = *text++;
    }

    buffer[position] = '\0';
    return position;
}

static void ui_format_peak_frequency(uint32_t frequency_hz,
                                     char *buffer,
                                     uint32_t buffer_size)
{
    uint32_t position = 0U;

    if ((buffer == NULL) || (buffer_size == 0U))
    {
        return;
    }

    buffer[0] = '\0';

    if (frequency_hz < 1000U)
    {
        position = ui_append_uint_text(buffer,
                                       buffer_size,
                                       position,
                                       frequency_hz,
                                       1U);
        (void)ui_append_text(buffer,
                            buffer_size,
                            position,
                            " Hz");
    }
    else if (frequency_hz < 10000U)
    {
        uint32_t rounded_hundredths =
            (frequency_hz + 5U) / 10U;
        uint32_t whole_khz = rounded_hundredths / 100U;
        uint32_t fraction = rounded_hundredths % 100U;

        position = ui_append_uint_text(buffer,
                                       buffer_size,
                                       position,
                                       whole_khz,
                                       1U);
        position = ui_append_text(buffer,
                                  buffer_size,
                                  position,
                                  ".");
        position = ui_append_uint_text(buffer,
                                       buffer_size,
                                       position,
                                       fraction,
                                       2U);
        (void)ui_append_text(buffer,
                            buffer_size,
                            position,
                            " kHz");
    }
    else
    {
        uint32_t rounded_tenths =
            (frequency_hz + 50U) / 100U;
        uint32_t whole_khz = rounded_tenths / 10U;
        uint32_t fraction = rounded_tenths % 10U;

        position = ui_append_uint_text(buffer,
                                       buffer_size,
                                       position,
                                       whole_khz,
                                       1U);
        position = ui_append_text(buffer,
                                  buffer_size,
                                  position,
                                  ".");
        position = ui_append_uint_text(buffer,
                                       buffer_size,
                                       position,
                                       fraction,
                                       1U);
        (void)ui_append_text(buffer,
                            buffer_size,
                            position,
                            " kHz");
    }
}

'''

text = once(text, old_helper, new_helper, "snprintf peak-frequency formatter")

text = once(
    text,
    "/* FFT_PEAK_FREQUENCY_UNITS_PATCH */\n",
    """/* FFT_PEAK_FREQUENCY_UNITS_PATCH */
/* FFT_PEAK_UNITS_NO_STDIO_FIX */
""",
    "FFT peak units marker",
)

text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"

if "snprintf" in text or "#include <stdio.h>" in text:
    fail("stdio dependency remains after repair")
if text.count("{") != text.count("}"):
    fail("Brace balance failed")
if text.count("/*") != text.count("*/"):
    fail("Comment balance failed")
if b"\x00" in text.encode("utf-8"):
    fail("Binary NUL generated")

for symbol in (
    MARKER,
    "ui_append_uint_text",
    "ui_append_text",
    "ui_format_peak_frequency",
    '" Hz"',
    '" kHz"',
):
    if symbol not in text:
        fail("Missing generated symbol: " + symbol)

UI_C.write_text(text, encoding="utf-8")

print("FFT peak-unit no-stdio repair applied successfully.")
print("Removed snprintf and stdio from Core/Src/ui.c.")
print("Hz/kHz formatting now uses a small freestanding integer formatter.")
print("Next: make clean && make -j4")
