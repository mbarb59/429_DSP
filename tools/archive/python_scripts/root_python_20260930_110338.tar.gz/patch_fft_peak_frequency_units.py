#!/usr/bin/env python3
"""Add automatic Hz/kHz formatting to the recorded FFT PEAK status field."""

from pathlib import Path
import re
import shutil

UI_C = Path("Core/Src/ui.c")
MARKER = "FFT_PEAK_FREQUENCY_UNITS_PATCH"


def fail(message):
    raise SystemExit(message)


def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}, found {count}")
    return text.replace(old, new, 1)


if not UI_C.exists():
    fail(f"Missing required file: {UI_C}")

raw = UI_C.read_bytes()
if b"\x00" in raw:
    fail("Binary NUL found in Core/Src/ui.c")

text = raw.decode("utf-8")

if MARKER in text:
    fail("FFT peak-frequency unit formatting is already installed")

if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact found in Core/Src/ui.c")

for prerequisite in (
    "RECORDED_FFT_DB_DISPLAY_V1_PATCH",
    "UI_MODE_RECORDED_FFT",
    "FFT_GetPeakFrequency()",
    'Display_DrawString(210, UI_STATUS_TOP + 8,',
):
    if prerequisite not in text:
        fail("Missing prerequisite: " + prerequisite)

backup = UI_C.with_name(UI_C.name + ".before_fft_peak_frequency_units")
if not backup.exists():
    shutil.copy2(UI_C, backup)

# snprintf is used only with integer fields, so this does not enable floating-
# point printf support.
text = once(
    text,
    "#include <string.h>\n",
    """#include <string.h>
#include <stdio.h>
""",
    "string include",
)

text = once(
    text,
    """static void ui_draw_uint(
    int32_t x,
    int32_t y,
    uint32_t value,
    uint16_t color);
""",
    """static void ui_draw_uint(
    int32_t x,
    int32_t y,
    uint32_t value,
    uint16_t color);
static void ui_format_peak_frequency(uint32_t frequency_hz,
                                     char *buffer,
                                     uint32_t buffer_size);
""",
    "ui_draw_uint prototype",
)

helper = r'''static void ui_format_peak_frequency(uint32_t frequency_hz,
                                     char *buffer,
                                     uint32_t buffer_size)
{
    if ((buffer == NULL) || (buffer_size == 0U))
    {
        return;
    }

    if (frequency_hz < 1000U)
    {
        (void)snprintf(buffer,
                       buffer_size,
                       "%lu Hz",
                       (unsigned long)frequency_hz);
    }
    else if (frequency_hz < 10000U)
    {
        uint32_t rounded_hundredths =
            (frequency_hz + 5U) / 10U;
        uint32_t whole_khz = rounded_hundredths / 100U;
        uint32_t fraction = rounded_hundredths % 100U;

        (void)snprintf(buffer,
                       buffer_size,
                       "%lu.%02lu kHz",
                       (unsigned long)whole_khz,
                       (unsigned long)fraction);
    }
    else
    {
        uint32_t rounded_tenths =
            (frequency_hz + 50U) / 100U;
        uint32_t whole_khz = rounded_tenths / 10U;
        uint32_t fraction = rounded_tenths % 10U;

        (void)snprintf(buffer,
                       buffer_size,
                       "%lu.%01lu kHz",
                       (unsigned long)whole_khz,
                       (unsigned long)fraction);
    }

    buffer[buffer_size - 1U] = '\0';
}

'''

# Insert immediately before the ui_draw_uint implementation, not its prototype.
ui_draw_uint_signature = "static void ui_draw_uint(\n"
ui_draw_uint_position = text.rfind(ui_draw_uint_signature)

if ui_draw_uint_position < 0:
    fail("Missing ui_draw_uint implementation")

text = (
    text[:ui_draw_uint_position]
    + helper
    + text[ui_draw_uint_position:]
)

old_status = '''            Display_DrawString(210, UI_STATUS_TOP + 8,
                               "PEAK", COLOR_WHITE, COLOR_BLACK);
            ui_draw_uint(246, UI_STATUS_TOP + 8,
                         FFT_GetPeakFrequency(), COLOR_GREEN);
'''

new_status = '''            char peak_frequency_text[16];

            Display_DrawString(202, UI_STATUS_TOP + 8,
                               "PEAK", COLOR_WHITE, COLOR_BLACK);
            ui_format_peak_frequency(
                FFT_GetPeakFrequency(),
                peak_frequency_text,
                sizeof(peak_frequency_text));
            Display_DrawString(238, UI_STATUS_TOP + 8,
                               peak_frequency_text,
                               COLOR_GREEN,
                               COLOR_BLACK);
'''

text = once(text, old_status, new_status, "recorded FFT PEAK status field")

text = once(
    text,
    "/* RECORDED_FFT_DB_DISPLAY_V1_PATCH */\n",
    """/* RECORDED_FFT_DB_DISPLAY_V1_PATCH */
/* FFT_PEAK_FREQUENCY_UNITS_PATCH */
""",
    "recorded FFT dB marker",
)

text = "\n".join(line.rstrip() for line in text.splitlines()) + "\n"

if text.count("{") != text.count("}"):
    fail("Brace balance failed")
if text.count("/*") != text.count("*/"):
    fail("Comment balance failed")
if re.search(r"&(lt|gt|amp);|<br", text):
    fail("HTML artifact generated")
if b"\x00" in text.encode("utf-8"):
    fail("Binary NUL generated")

for symbol in (
    MARKER,
    "ui_format_peak_frequency",
    '"%lu Hz"',
    '"%lu.%02lu kHz"',
    '"%lu.%01lu kHz"',
    "peak_frequency_text",
):
    if symbol not in text:
        fail("Missing generated symbol: " + symbol)

UI_C.write_text(text, encoding="utf-8")

print("FFT peak Hz/kHz formatting patch applied successfully.")
print("Modified: Core/Src/ui.c")
print("Below 1 kHz: whole Hz, e.g. 47 Hz")
print("1 to 9.99 kHz: two decimals, e.g. 1.03 kHz")
print("10 kHz and above: one decimal, e.g. 12.4 kHz")
print("FFT calculations, recorder, DMA, and SD paths were unchanged.")
print("Next: make clean && make -j4")
